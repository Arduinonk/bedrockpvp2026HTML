# One-tick guard for player interaction handling.
scoreboard players remove @a[scores={bsc.cooldown=1..}] bsc.cooldown 1

# Keep click-catcher entities stable long enough for the client to know about them.
# The previous implementation killed/re-summoned them every tick, which could make
# right-clicks intermittently miss because of client/server entity synchronization.
scoreboard players add @e[type=minecraft:interaction,tag=bsc.cane_target] bsc.target_age 1
kill @e[type=minecraft:interaction,tag=bsc.cane_target,scores={bsc.target_age=5..}]

# Refresh/create a temporary click catcher in FRONT of the cane currently under the crosshair.
execute as @a if items entity @s weapon.mainhand minecraft:bone_meal at @s run function bsc:target/start
execute as @a unless items entity @s weapon.mainhand minecraft:bone_meal if items entity @s weapon.offhand minecraft:bone_meal at @s run function bsc:target/start

# Watch registered dispensers and handle each redstone activation once.
execute as @e[type=minecraft:marker,tag=bsc.dispenser] at @s run function bsc:dispenser/tick
