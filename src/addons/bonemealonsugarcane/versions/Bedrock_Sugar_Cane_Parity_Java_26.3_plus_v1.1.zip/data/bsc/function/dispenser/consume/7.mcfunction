item modify block ~ ~ ~ container.7 bsc:decrement_one
scoreboard players set @s bsc.used 1
