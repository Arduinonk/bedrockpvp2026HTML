# Only consume/show effects when grow_base marked a successful fertilization.
execute unless score @s bsc.success matches 1.. run return 0

particle minecraft:happy_villager ~0.5 ~1.0 ~0.5 0.35 0.75 0.35 0.0 12 force
playsound minecraft:item.bone_meal.use block @a[distance=..16] ~0.5 ~0.5 ~0.5 1.0 1.0

# Creative mode keeps the item. Survival/Adventure remove exactly one from the hand used.
execute unless entity @s[gamemode=creative] if score @s bsc.hand matches 0 run item modify entity @s weapon.mainhand bsc:decrement_one
execute unless entity @s[gamemode=creative] if score @s bsc.hand matches 1 run item modify entity @s weapon.offhand bsc:decrement_one
