execute if block ~ ~ ~ minecraft:sugar_cane run function bsc:player/break_here
execute if block ~ ~ ~ minecraft:sugar_cane run return 1
execute unless block ~ ~ ~ #bsc:ray_passable run return 0

scoreboard players add @s bsc.ray 1
execute if score @s bsc.ray matches ..32 positioned ^ ^ ^0.2 run function bsc:player/break_raycast
