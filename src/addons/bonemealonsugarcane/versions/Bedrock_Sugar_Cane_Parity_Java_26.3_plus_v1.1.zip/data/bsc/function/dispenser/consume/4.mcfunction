item modify block ~ ~ ~ container.4 bsc:decrement_one
scoreboard players set @s bsc.used 1
