# Survival gets the normal cane drop. Creative removes the clicked cane without its own drop.
# Adventure/Spectator intentionally do nothing, preserving vanilla break restrictions.
execute if entity @s[gamemode=survival] run setblock ~ ~ ~ minecraft:air destroy
execute if entity @s[gamemode=creative] run setblock ~ ~ ~ minecraft:air
