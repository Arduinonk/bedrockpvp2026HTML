particle minecraft:happy_villager ~0.5 ~1.0 ~0.5 0.35 0.75 0.35 0.0 12 force
playsound minecraft:item.bone_meal.use block @a[distance=..16] ~0.5 ~0.5 ~0.5 1.0 1.0

# Return execution to the marker at the dispenser and remove exactly one bone meal.
execute at @s run function bsc:dispenser/consume
