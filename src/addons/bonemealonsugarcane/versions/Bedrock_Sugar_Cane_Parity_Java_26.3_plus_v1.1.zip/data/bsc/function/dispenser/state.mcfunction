# Reset edge detector after the dispenser is no longer triggered.
execute if block ~ ~ ~ minecraft:dispenser[triggered=false] run tag @s remove bsc.triggered

# Handle each redstone activation once.
execute if block ~ ~ ~ minecraft:dispenser[triggered=true] unless entity @s[tag=bsc.triggered] run function bsc:dispenser/activate
