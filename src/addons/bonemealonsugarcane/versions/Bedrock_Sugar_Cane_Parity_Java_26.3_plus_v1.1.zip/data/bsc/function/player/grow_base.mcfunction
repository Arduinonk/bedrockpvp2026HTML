# Bedrock parity: one bone meal grows the plant toward its natural max height of 3.
scoreboard players set @s bsc.success 0

# Height 1: add the second block if possible.
execute if block ~ ~1 ~ minecraft:air run scoreboard players set @s bsc.success 1
execute if score @s bsc.success matches 1 run setblock ~ ~1 ~ minecraft:sugar_cane

# Height 2 (including the block just added above): add the third block if possible.
execute if block ~ ~1 ~ minecraft:sugar_cane if block ~ ~2 ~ minecraft:air run scoreboard players set @s bsc.success 2
execute if score @s bsc.success matches 2 run setblock ~ ~2 ~ minecraft:sugar_cane

execute if score @s bsc.success matches 1.. run function bsc:player/finalize
