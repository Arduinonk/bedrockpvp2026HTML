item modify block ~ ~ ~ container.6 bsc:decrement_one
scoreboard players set @s bsc.used 1
