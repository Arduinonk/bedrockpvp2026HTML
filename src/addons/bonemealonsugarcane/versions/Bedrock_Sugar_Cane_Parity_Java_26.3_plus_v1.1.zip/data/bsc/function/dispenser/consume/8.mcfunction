item modify block ~ ~ ~ container.8 bsc:decrement_one
scoreboard players set @s bsc.used 1
