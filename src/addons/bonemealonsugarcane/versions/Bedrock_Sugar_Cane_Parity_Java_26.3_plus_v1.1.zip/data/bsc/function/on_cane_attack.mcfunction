# The temporary Interaction hitbox would otherwise swallow left-clicks.
# Reproduce normal sugar-cane breaking for Survival and Creative players.
advancement revoke @s only bsc:attack_cane
scoreboard players set @s bsc.ray 0
execute anchored eyes positioned ^ ^ ^ run function bsc:player/break_raycast
