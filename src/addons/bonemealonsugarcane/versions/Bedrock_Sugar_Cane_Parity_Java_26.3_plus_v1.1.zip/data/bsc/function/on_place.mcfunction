# Re-arm the placement advancement and register a newly placed dispenser if it is in the crosshair.
advancement revoke @s only bsc:place_block
function bsc:register/start
