execute unless entity @e[type=minecraft:marker,tag=bsc.dispenser,distance=..0.12] run summon minecraft:marker ~ ~ ~ {Tags:["bsc.dispenser"]}
