execute if block ~ ~ ~ minecraft:dispenser run function bsc:dispenser/state
execute unless block ~ ~ ~ minecraft:dispenser run kill @s
