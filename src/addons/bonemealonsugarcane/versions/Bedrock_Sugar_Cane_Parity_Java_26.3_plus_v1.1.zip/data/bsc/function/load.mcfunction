# Bedrock Sugar Cane Parity - initialization
scoreboard objectives add bsc.ray dummy
scoreboard objectives add bsc.cooldown dummy
scoreboard objectives add bsc.hand dummy
scoreboard objectives add bsc.success dummy
scoreboard objectives add bsc.valid dummy
scoreboard objectives add bsc.used dummy
scoreboard objectives add bsc.target_age dummy

# Remove stale temporary hitboxes left by an older datapack version/reload.
kill @e[type=minecraft:interaction,tag=bsc.cane_target]

# This trigger is only for discovering dispensers that existed before the datapack was installed.
# any_block_use is reliable for opening a dispenser GUI; it is NOT used for sugar-cane fertilization.
advancement revoke @s only bsc:use_block
function bsc:register/start
