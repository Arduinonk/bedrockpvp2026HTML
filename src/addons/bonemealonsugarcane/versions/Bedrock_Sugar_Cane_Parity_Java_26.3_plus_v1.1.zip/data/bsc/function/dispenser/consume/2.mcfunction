item modify block ~ ~ ~ container.2 bsc:decrement_one
scoreboard players set @s bsc.used 1
