tag @s add bsc.triggered

# Pure-datapack limitation: Minecraft does not expose which random dispenser slot was selected.
# To avoid consuming/growing incorrectly, parity mode only runs when every occupied slot contains bone meal.
scoreboard players set @s bsc.valid 1
execute if items block ~ ~ ~ container.0 * unless items block ~ ~ ~ container.0 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.1 * unless items block ~ ~ ~ container.1 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.2 * unless items block ~ ~ ~ container.2 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.3 * unless items block ~ ~ ~ container.3 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.4 * unless items block ~ ~ ~ container.4 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.5 * unless items block ~ ~ ~ container.5 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.6 * unless items block ~ ~ ~ container.6 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.7 * unless items block ~ ~ ~ container.7 minecraft:bone_meal run scoreboard players set @s bsc.valid 0
execute if items block ~ ~ ~ container.8 * unless items block ~ ~ ~ container.8 minecraft:bone_meal run scoreboard players set @s bsc.valid 0

execute unless score @s bsc.valid matches 1 run return 0
execute unless items block ~ ~ ~ container.* minecraft:bone_meal run return 0

# Dispatch to the block directly in front of the dispenser.
execute if block ~ ~ ~ minecraft:dispenser[facing=north] if block ~ ~ ~-1 minecraft:sugar_cane positioned ~ ~ ~-1 run function bsc:dispenser/find_base
execute if block ~ ~ ~ minecraft:dispenser[facing=south] if block ~ ~ ~1 minecraft:sugar_cane positioned ~ ~ ~1 run function bsc:dispenser/find_base
execute if block ~ ~ ~ minecraft:dispenser[facing=west] if block ~-1 ~ ~ minecraft:sugar_cane positioned ~-1 ~ ~ run function bsc:dispenser/find_base
execute if block ~ ~ ~ minecraft:dispenser[facing=east] if block ~1 ~ ~ minecraft:sugar_cane positioned ~1 ~ ~ run function bsc:dispenser/find_base
execute if block ~ ~ ~ minecraft:dispenser[facing=up] if block ~ ~1 ~ minecraft:sugar_cane positioned ~ ~1 ~ run function bsc:dispenser/find_base
execute if block ~ ~ ~ minecraft:dispenser[facing=down] if block ~ ~-1 ~ minecraft:sugar_cane positioned ~ ~-1 ~ run function bsc:dispenser/find_base
