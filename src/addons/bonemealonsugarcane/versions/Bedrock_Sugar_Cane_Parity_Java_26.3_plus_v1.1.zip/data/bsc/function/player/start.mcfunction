scoreboard players set @s bsc.cooldown 1
scoreboard players set @s bsc.ray 0
execute anchored eyes positioned ^ ^ ^ run function bsc:player/raycast
