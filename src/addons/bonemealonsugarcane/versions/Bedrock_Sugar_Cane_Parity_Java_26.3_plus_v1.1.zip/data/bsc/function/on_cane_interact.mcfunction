# Re-arm immediately so every future click can trigger again.
advancement revoke @s only bsc:right_click_cane

# A target only exists while this player is aiming at cane with Bone Meal in either hand,
# but re-check the inventory here so item switching cannot create a free growth.
execute if score @s bsc.cooldown matches 1.. run return 0
scoreboard players set @s bsc.hand -1

# Main hand has vanilla interaction priority.
execute if items entity @s weapon.mainhand minecraft:bone_meal run scoreboard players set @s bsc.hand 0
execute unless items entity @s weapon.mainhand minecraft:bone_meal if items entity @s weapon.offhand minecraft:bone_meal run scoreboard players set @s bsc.hand 1

execute unless score @s bsc.hand matches 0..1 run return 0
function bsc:player/start
