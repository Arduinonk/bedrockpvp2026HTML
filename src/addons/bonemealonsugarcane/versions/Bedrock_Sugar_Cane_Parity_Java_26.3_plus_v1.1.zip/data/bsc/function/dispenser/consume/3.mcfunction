item modify block ~ ~ ~ container.3 bsc:decrement_one
scoreboard players set @s bsc.used 1
