# Walk down the connected sugar-cane column to its base.
execute if block ~ ~-1 ~ minecraft:sugar_cane positioned ~ ~-1 ~ run function bsc:player/find_base
execute unless block ~ ~-1 ~ minecraft:sugar_cane run function bsc:player/grow_base
