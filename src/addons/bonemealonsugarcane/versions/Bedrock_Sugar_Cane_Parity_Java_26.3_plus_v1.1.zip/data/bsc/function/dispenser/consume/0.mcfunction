item modify block ~ ~ ~ container.0 bsc:decrement_one
scoreboard players set @s bsc.used 1
