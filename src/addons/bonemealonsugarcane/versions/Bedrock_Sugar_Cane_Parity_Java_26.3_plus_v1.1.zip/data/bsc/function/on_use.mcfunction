# This trigger is only for discovering dispensers that existed before the datapack was installed.
# any_block_use is reliable for opening a dispenser GUI; it is NOT used for sugar-cane fertilization.
advancement revoke @s only bsc:use_block
function bsc:register/start
