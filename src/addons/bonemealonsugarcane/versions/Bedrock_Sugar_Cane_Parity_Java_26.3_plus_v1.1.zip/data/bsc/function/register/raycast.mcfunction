execute if block ~ ~ ~ minecraft:dispenser align xyz positioned ~0.5 ~0.5 ~0.5 run function bsc:register/mark
execute if block ~ ~ ~ minecraft:dispenser run return 1
execute unless block ~ ~ ~ #bsc:ray_passable run return 0
scoreboard players add @s bsc.ray 1
execute if score @s bsc.ray matches ..32 positioned ^ ^ ^0.2 run function bsc:register/raycast
