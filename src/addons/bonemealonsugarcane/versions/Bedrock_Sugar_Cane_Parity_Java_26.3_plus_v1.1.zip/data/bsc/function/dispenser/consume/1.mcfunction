item modify block ~ ~ ~ container.1 bsc:decrement_one
scoreboard players set @s bsc.used 1
