item modify block ~ ~ ~ container.5 bsc:decrement_one
scoreboard players set @s bsc.used 1
