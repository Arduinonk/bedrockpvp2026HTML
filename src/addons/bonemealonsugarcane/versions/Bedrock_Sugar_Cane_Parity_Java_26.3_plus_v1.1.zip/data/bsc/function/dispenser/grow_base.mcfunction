scoreboard players set @s bsc.success 0

# Existing height 1 -> grow to 2, then to 3 if space permits.
execute if block ~ ~1 ~ minecraft:air run scoreboard players set @s bsc.success 1
execute if score @s bsc.success matches 1 run setblock ~ ~1 ~ minecraft:sugar_cane

# Existing/new height 2 -> grow to 3 if possible.
execute if block ~ ~1 ~ minecraft:sugar_cane if block ~ ~2 ~ minecraft:air run scoreboard players set @s bsc.success 2
execute if score @s bsc.success matches 2 run setblock ~ ~2 ~ minecraft:sugar_cane

execute if score @s bsc.success matches 1.. run function bsc:dispenser/finalize
