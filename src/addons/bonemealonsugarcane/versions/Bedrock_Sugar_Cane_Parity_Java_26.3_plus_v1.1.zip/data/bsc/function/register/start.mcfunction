scoreboard players set @s bsc.ray 0
execute anchored eyes positioned ^ ^ ^ run function bsc:register/raycast
