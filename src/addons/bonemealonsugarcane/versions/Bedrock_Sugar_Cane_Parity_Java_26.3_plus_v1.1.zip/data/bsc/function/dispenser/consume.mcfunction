scoreboard players set @s bsc.used 0
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.0 minecraft:bone_meal run function bsc:dispenser/consume/0
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.1 minecraft:bone_meal run function bsc:dispenser/consume/1
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.2 minecraft:bone_meal run function bsc:dispenser/consume/2
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.3 minecraft:bone_meal run function bsc:dispenser/consume/3
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.4 minecraft:bone_meal run function bsc:dispenser/consume/4
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.5 minecraft:bone_meal run function bsc:dispenser/consume/5
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.6 minecraft:bone_meal run function bsc:dispenser/consume/6
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.7 minecraft:bone_meal run function bsc:dispenser/consume/7
execute if score @s bsc.used matches 0 if items block ~ ~ ~ container.8 minecraft:bone_meal run function bsc:dispenser/consume/8
