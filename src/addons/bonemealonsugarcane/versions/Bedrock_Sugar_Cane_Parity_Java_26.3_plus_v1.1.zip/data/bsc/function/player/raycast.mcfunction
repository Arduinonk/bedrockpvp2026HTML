# Stop on the sugar cane the player is actually looking at.
execute if block ~ ~ ~ minecraft:sugar_cane run function bsc:player/find_base
execute if block ~ ~ ~ minecraft:sugar_cane run return 1

# Do not fertilize cane hidden behind a solid target block.
execute unless block ~ ~ ~ #bsc:ray_passable run return 0

scoreboard players add @s bsc.ray 1
execute if score @s bsc.ray matches ..32 positioned ^ ^ ^0.2 run function bsc:player/raycast
