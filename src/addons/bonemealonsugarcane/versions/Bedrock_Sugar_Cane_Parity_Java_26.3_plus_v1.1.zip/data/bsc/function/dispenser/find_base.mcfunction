execute if block ~ ~-1 ~ minecraft:sugar_cane positioned ~ ~-1 ~ run function bsc:dispenser/find_base
execute unless block ~ ~-1 ~ minecraft:sugar_cane run function bsc:dispenser/grow_base
