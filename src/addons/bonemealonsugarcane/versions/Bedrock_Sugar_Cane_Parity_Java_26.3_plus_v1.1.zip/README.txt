BEDROCK SUGAR CANE PARITY
Target: Minecraft Java Edition 26.3 and later

WHAT IT DOES
- Right-click vanilla Sugar Cane with vanilla Bone Meal to grow it toward the normal 3-block maximum.
- Works from the main hand and the offhand.
- Consumes exactly 1 Bone Meal only when growth succeeds (Creative keeps the item).
- Bone Meal is not consumed when the cane is already 3+ blocks tall or there is no room above it.
- Preserves left-click breaking even though the pack uses a temporary invisible Interaction hitbox.
- Dispensers whose occupied slots contain only Bone Meal can fertilize Sugar Cane and consume exactly 1 Bone Meal.
- Newly placed dispensers are registered automatically. Existing dispensers are registered when you open/use them once.

INSTALL
1. Put the ZIP itself directly into: <world>/datapacks/
2. Run /reload, or restart/reopen the world.
3. Run /datapack list and confirm the pack is enabled.

HOW PLAYER DETECTION WORKS
Java does not natively treat Bone Meal on Sugar Cane as a successful block use. The pack therefore creates a tiny,
invisible vanilla minecraft:interaction entity over the Sugar Cane currently under the crosshair only while the
player is holding Bone Meal. Right-click and left-click advancement triggers then reproduce the missing behavior.
No mod, plugin, resource pack, experimental API, or Beta API is required.

VERSION POLICY
pack.mcmeta declares min_format 121.0 (Java 26.3) and max_format 999999.
This is intentionally forward-open so the pack does not become "outdated" merely because Mojang increments the
Data Pack version. Java Edition does NOT provide a promise equivalent to a forever-stable Bedrock non-Beta API:
if Mojang changes/removes command, advancement, predicate, entity, or item-modifier syntax in a future version,
an update can still be required. The pack uses a small set of vanilla features to reduce that risk.

DISPENSER NOTE (IMPORTANT)
A pure Java datapack cannot directly read which of a dispenser's 9 slots the dispenser randomly selected for that
activation. To avoid falsely growing cane or consuming the wrong item, the custom dispenser behavior activates only
when EVERY OCCUPIED SLOT in that dispenser contains Bone Meal. Empty slots are fine. This matches normal automated
Bone Meal farm layouts.

For a dispenser that already existed before installing this pack and is only driven by hoppers/redstone, either
open it once or break and place it once so the pack can register it.

v1.1 interaction reliability fix:
- Persistent/refreshing Interaction hitboxes instead of kill+resummon every tick.
- Click catcher is placed slightly in front of sugar cane to avoid block ray occlusion.
