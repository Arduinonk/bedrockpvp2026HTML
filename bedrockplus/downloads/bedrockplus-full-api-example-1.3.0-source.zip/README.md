# BedrockPlus full Python API example

This is the canonical, typed API v1 reference plugin. Version `1.3.0`
demonstrates every
feature that is connected to BDS in the current `1.26.51.1` development build:

- all six lifecycle callbacks;
- structured logs and private persistent data;
- one-shot/repeating scheduling and explicit cancellation;
- subscription/unsubscription for tick, player join/quit, and global player
  and server command events;
- command cancellation and in-place rewrite before vanilla execution;
- native `/bpexample` and `/bptypes` registration, aliases, overloads, and the
  `enum`, `int`, `number`, `string`, and `text` argument types, including
  literal action autocomplete;
- vanilla/BedrockPlus server-command dispatch;
- owner-scoped vanilla command hide/restore policies; and
- explicit command unregistration during orderly shutdown.
- typed `Server`, `Player`, `Level`, `Entity`, `Location`, `Vector3`, `ItemStack`,
  and `ConnectionInfo` objects. Connection fields remain optional until a native
  producer supplies them. This diagnostic example logs connection fields on join
  so the native bridge can be verified; production plugins should redact sensitive
  IP/device identifiers unless they are operationally required.

The source imports the PEP 561 typed `bedrockplus` package. For IDE autocomplete
in a plugin development environment, run this once from the repository root:

```powershell
python -m pip install -e .\sdk\python
```

## Build and install

```powershell
.\examples\plugins\python-full-featured\Prepare-Package.ps1
Copy-Item .\out\examples\bedrockplus-full-api-example-1.3.0.bppack `
  D:\Minecraft\BedrockPlusEngine\BedrockPlusServer\plugins\
```

Then enter the server folder and run `bedrockplus`.

## In-game tests

```text
/bpexample
/bpx stats
/bpexample say Hello from a plugin
/bpexample tell Player Name|Private message
/bpexample as Player Name|time set day
/bpexample kick Player Name|Example reason
/bpexample hide me
/bpexample restore me
/bptypes 7 1.5 word remaining text here
/bpday
/bpblocked
```

`/bpday` is cancelled as a player request and queues `time set day` through the
server command dispatcher, so it does not inherit the player's vanilla `time`
permission requirement. `/bpblocked` is cancelled before BDS handles it. In the
server console, `bpnight` is rewritten to `time set night`
and `bpblockedserver` is cancelled.

The canonical names for chat, block, movement, login, kick, jump, and server-list
ping are reserved by API v1 but do not yet have native BDS event producers. The
example deliberately does not pretend those callbacks are live.
