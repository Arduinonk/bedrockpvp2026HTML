"""Complete, typed BedrockPlus API v1 example.

The example intentionally uses only native event feeds that are implemented in
the current BDS 1.26.51.1 integration. Reserved future event names are listed in
the documentation, but are not subscribed here.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import cast

from bedrockplus import (
    CommandInvocation,
    CommandResult,
    Event,
    EventPriority,
    ItemStack,
    Level,
    PlayerCommandEvent,
    PlayerJoinEvent,
    PlayerQuitEvent,
    PluginHost,
    Server,
    ServerCommandEvent,
    ServerTickEvent,
)


class FullFeaturedPlugin:
    """Reference implementation for the complete working Python host API."""

    id = "bedrockplus.example.full-featured"
    name = "BedrockPlus Full API Example"
    version = "1.3.0"

    def __init__(self) -> None:
        self.host: PluginHost
        self.server: Server
        self.overworld: Level
        self.example_item: ItemStack
        self.data_path = Path()
        self.state_path = Path()
        self.state: dict[str, int] = {"starts": 0, "joins": 0}
        self.subscription_ids: list[int] = []
        self.task_ids: list[int] = []
        self.tick_count = 0

    def on_load(self, host: PluginHost) -> None:
        """Save the typed host and prepare this plugin's private data path."""
        self.host = host
        self.server = Server(host)
        # These immutable objects establish the same typed vocabulary that
        # future block/entity/inventory events will use.
        self.overworld = self.server.level("BedrockPlus", "minecraft:overworld")
        self.example_item = self.server.item_stack("minecraft:diamond", amount=1)
        self.data_path = self.server.data_directory
        self.state_path = self.data_path / "state.json"
        host.log("info", "EXAMPLE.LOAD", "Full API example loaded")

    def on_enable(self) -> None:
        """Load persistent data before BDS runtime services are registered."""
        self.data_path.mkdir(parents=True, exist_ok=True)
        if self.state_path.is_file():
            try:
                loaded = json.loads(self.state_path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.state["starts"] = int(loaded.get("starts", 0))
                    self.state["joins"] = int(loaded.get("joins", 0))
            except (OSError, ValueError, TypeError):
                self.host.log(
                    "warning",
                    "EXAMPLE.STATE_INVALID",
                    "Invalid state.json was ignored",
                    {"path": str(self.state_path)},
                )
        self.state["starts"] += 1
        self._save_state()
        self.host.log(
            "info",
            "EXAMPLE.ENABLE",
            "Full API example enabled",
            {"starts": str(self.state["starts"])},
        )

    def on_server_ready(self) -> None:
        """Register commands, live event listeners, and scheduled callbacks."""
        if not self.host.commands_available():
            raise RuntimeError("BedrockPlus command service is unavailable")
        if not self.host.events_available():
            raise RuntimeError("BedrockPlus event service is unavailable")
        if not self.host.scheduler_available():
            raise RuntimeError("BedrockPlus scheduler service is unavailable")

        # A native slash command with an alias and optional trailing text.
        self.host.register_command(
            "bpexample",
            self.on_example_command,
            description="Exercise the BedrockPlus Python API",
            aliases=["bpx"],
            overloads=[
                [],
                [
                    {
                        "name": "action",
                        "type": "enum",
                        "choices": ["say", "tell", "as", "kick", "hide", "restore", "stats"],
                    },
                    {"name": "value", "type": "text", "optional": True},
                ],
            ],
        )

        # The previous command demonstrates enum autocomplete; this one covers
        # every scalar and trailing-text argument type.
        self.host.register_command(
            "bptypes",
            self.on_types_command,
            description="Test int, number, string, and text arguments",
            overloads=[[
                {"name": "count", "type": "int"},
                {"name": "ratio", "type": "number"},
                {"name": "word", "type": "string"},
                {"name": "message", "type": "text"},
            ]],
        )

        # Only these five native feeds are currently produced by BedrockPlus.
        self.subscription_ids.extend([
            self.host.subscribe_event("server.tick", self.on_tick),
            self.host.subscribe_event("player.join", self.on_player_join),
            self.host.subscribe_event("player.quit", self.on_player_quit),
            self.host.subscribe_event(
                "player.command", self.on_player_command, EventPriority.HIGH
            ),
            self.host.subscribe_event(
                "server.command", self.on_server_command, EventPriority.HIGH
            ),
        ])

        # Schedule a one-shot task and a three-run repeating task.
        self.task_ids.append(self.host.schedule(self.on_delayed_task, delay_ms=1000))
        self.task_ids.append(
            self.host.schedule(
                self.on_repeating_task,
                delay_ms=2000,
                interval_ms=2000,
                runs=3,
            )
        )

        # Schedule then cancel a task to show explicit task cancellation.
        cancelled_id = self.host.schedule(self.on_cancelled_task, delay_ms=60_000)
        self.host.cancel_task(cancelled_id)

        self.host.log(
            "info",
            "EXAMPLE.READY",
            "Try /bpexample, /bptypes, /bpday, and /bpblocked",
            {"server": self.server.name, "api": str(self.server.api_version)},
        )

    def on_example_command(self, invocation: CommandInvocation) -> CommandResult:
        """Handle /bpexample and demonstrate server dispatch/policy APIs."""
        args = invocation["args"]
        if not args:
            return {
                "succeeded": True,
                "message": (
                    "API example is active. Actions: say, tell, as, kick, "
                    "hide, restore, stats. "
                    "Also try /bpday and /bpblocked."
                ),
            }

        action = str(args[0]).casefold()
        value = str(args[1]).strip() if len(args) > 1 else ""

        if action == "say":
            if not value:
                return {"succeeded": False, "message": "Usage: /bpexample say <text>"}
            accepted = self.server.broadcast(f"&d[BedrockPlus example]&r {value}")
            return {
                "succeeded": accepted,
                "message": "Server command queued" if accepted else "Queue rejected",
            }

        # Player actions use "player name|value" so names may contain spaces.
        if action in {"tell", "as", "kick"}:
            player_name, action_value = self._split_player_action(value)
            if not player_name:
                return {
                    "succeeded": False,
                    "message": f"Usage: /bpexample {action} <player>|<value>",
                }
            player = self.server.player(player_name)
            if action == "tell":
                accepted = bool(action_value) and player.send_message(action_value)
            elif action == "as":
                accepted = bool(action_value) and player.run_command(action_value)
            else:
                accepted = player.kick(action_value or "Kicked by the API example")
            return {
                "succeeded": accepted,
                "message": f"{action} queued for {player.display_name}",
            }

        if action in {"hide", "restore"}:
            command_name = value.lstrip("/").split(" ", 1)[0]
            if not command_name:
                return {
                    "succeeded": False,
                    "message": f"Usage: /bpexample {action} <vanilla-command>",
                }
            changed = (
                self.host.hide_vanilla_command(command_name)
                if action == "hide"
                else self.host.restore_vanilla_command(command_name)
            )
            return {
                "succeeded": changed,
                "message": f"{action}: {command_name}",
            }

        if action == "stats":
            return {
                "succeeded": True,
                "message": (
                    f"starts={self.state['starts']}; joins={self.state['joins']}; "
                    f"source={invocation['source_name']}; server={self.server.name}; "
                    f"api={self.server.api_version}; level={self.overworld.name}; "
                    f"item={self.example_item.type_id}"
                ),
            }

        return {
            "succeeded": False,
            "message": f"Unknown action: {action}",
            "error_code": "EXAMPLE_UNKNOWN_ACTION",
        }

    def on_types_command(self, invocation: CommandInvocation) -> CommandResult:
        """Receive BDS-parsed int, float, one-token string, and remaining text."""
        count, ratio, word, message = invocation["args"]
        return {
            "succeeded": True,
            "message": (
                f"count={int(count)}; ratio={float(ratio):g}; "
                f"word={word}; message={message}"
            ),
        }

    def on_tick(self, event: Event) -> None:
        """Observe the server-thread tick feed without flooding the log."""
        tick = cast(ServerTickEvent, event)
        self.tick_count += 1
        if self.tick_count == 1:
            self.host.log(
                "debug",
                "EXAMPLE.FIRST_TICK",
                "First observed server tick",
                {"sequence": str(tick["sequence"])},
            )

    def on_player_join(self, event: Event) -> None:
        """Read native player fields and persist a join counter."""
        joined = cast(PlayerJoinEvent, event)
        player = self.server.player_from_event(joined)
        self.state["joins"] += 1
        self._save_state()
        player.send_message("&aWelcome! &fThis message uses the Player object.")
        address = (
            f"{player.address.host}:{player.address.port}"
            if player.address is not None
            else "n/a"
        )
        connection_summary = " | ".join(
            (
                f"session={player.session_id}",
                f"xuid={player.xuid or 'n/a'}",
                f"connection={'yes' if player.connection is not None else 'no'}",
                f"address={address}",
                f"device_id={player.device_id or 'n/a'}",
                f"device_model={player.device_model or 'n/a'}",
                f"device_os={player.device_os or 'n/a'}",
                f"input={player.input_mode or 'n/a'}",
                f"game={player.game_version or 'n/a'}",
                f"locale={player.locale or 'n/a'}",
                f"ping_ms={player.ping_ms if player.ping_ms is not None else 'n/a'}",
            )
        )
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_JOIN",
            f"{player.display_name} joined | {connection_summary}",
            {
                "session": player.session_id,
                "connection_available": str(player.connection is not None),
                "ping_ms": str(player.ping_ms) if player.ping_ms is not None else "",
                "device_model": player.device_model,
                "device_os": player.device_os,
                "input_mode": player.input_mode,
                "game_version": player.game_version,
                "locale": player.locale,
                "address": address,
                "device_id": player.device_id,
            },
        )

    def on_player_quit(self, event: Event) -> None:
        """Observe a native player disconnect event."""
        left = cast(PlayerQuitEvent, event)
        fields = left["fields"]
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_QUIT",
            f"{fields['player.name']} left",
            {"session": fields["player.session"]},
        )

    def on_player_command(self, event: Event) -> None:
        """Cancel /bpblocked and run /bpday through the server command queue."""
        command_event = cast(PlayerCommandEvent, event)
        fields = command_event["fields"]
        command = fields["command"].lstrip("/").casefold()
        if command == "bpblocked":
            command_event["cancelled"] = True
        elif command == "bpday":
            # Rewriting to `time` would retain the player's vanilla permission
            # level. Cancel the player request and dispatch as server instead.
            command_event["cancelled"] = True
            self.server.dispatch_command("time set day")

    def on_server_command(self, event: Event) -> None:
        """Apply the same control model to commands entered in the console."""
        command_event = cast(ServerCommandEvent, event)
        fields = command_event["fields"]
        command = fields["command"].lstrip("/").casefold()
        if command == "bpblockedserver":
            command_event["cancelled"] = True
        elif command == "bpnight":
            fields["command"] = "time set night"

    def on_delayed_task(self) -> None:
        self.host.log("info", "EXAMPLE.DELAYED_TASK", "One-shot task ran")

    def on_repeating_task(self) -> None:
        self.host.log("debug", "EXAMPLE.REPEATING_TASK", "Repeating task ran")

    def on_cancelled_task(self) -> None:
        # This must never execute because it is cancelled in on_server_ready.
        self.host.log("error", "EXAMPLE.CANCEL_FAILED", "Cancelled task executed")

    def on_server_stopping(self) -> None:
        """Explicitly release owned resources before host teardown."""
        for task_id in self.task_ids:
            self.host.cancel_task(task_id)
        self.task_ids.clear()

        for subscription_id in self.subscription_ids:
            self.host.unsubscribe_event(subscription_id)
        self.subscription_ids.clear()

        self.host.unregister_command("bpexample")
        self.host.unregister_command("bptypes")
        self.host.log("info", "EXAMPLE.STOPPING", "Example resources released")

    def on_disable(self) -> None:
        self._save_state()
        self.host.log("info", "EXAMPLE.DISABLE", "Full API example disabled")

    def on_unload(self) -> None:
        """No host calls are made after this final lifecycle callback."""

    def _save_state(self) -> None:
        # Keep the reference compatible with Windows security scanners and
        # backup tools that can briefly hold newly-created temporary files.
        self.state_path.write_text(
            json.dumps(self.state, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    @staticmethod
    def _split_player_action(value: str) -> tuple[str, str]:
        player_name, separator, action_value = value.partition("|")
        return player_name.strip(), action_value.strip() if separator else ""
