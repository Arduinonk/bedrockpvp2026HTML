"""Complete, typed BedrockPlus API v1 example for BDS 1.26.51.1."""

from __future__ import annotations

import json
from collections.abc import Iterator
from ipaddress import ip_address
from pathlib import Path

from bedrockplus import (
    Block,
    BlockTypes,
    BlockBreakEvent,
    BlockPlaceEvent,
    BossBar,
    BossBarColor,
    BossBarError,
    BossBarStyle,
    CameraPresetTypes,
    CameraShakeType,
    CommandArgument,
    CommandInvocation,
    CommandResult,
    EventPriority,
    GameMode,
    InputPermission,
    ItemStack,
    ItemTypes,
    DimensionTypes,
    PlayerChatEvent,
    PlayerCommandEvent,
    PlayerDeathEvent,
    PlayerJoinEvent,
    PlayerInteractEvent,
    PlayerJumpEvent,
    PlayerKickEvent,
    PlayerLoginEvent,
    PlayerMoveEvent,
    PlayerQuitEvent,
    PlayerRespawnEvent,
    PlayerToggleSneakEvent,
    PlayerToggleSprintEvent,
    Player,
    PluginHost,
    Server,
    ServerCommandEvent,
    ServerListPingEvent,
    ServerTickEvent,
    System,
    Vector2,
    Vector3,
)


class FullFeaturedPlugin:
    """Reference implementation for the complete working Python host API."""

    id = "bedrockplus.example.full-featured"
    name = "BedrockPlus Full API Example"
    version = "1.16.0"

    motd_messages = (
        "BedrockPlus API example",
        "Typed Python plugins are running",
        "Cancellable events are enabled",
        "Native slash commands are enabled",
        "Scheduled tasks are active",
    )

    def __init__(self) -> None:
        self.host: PluginHost
        self.server: Server
        self.system: System
        self.data_path = Path()
        self.state_path = Path()
        self.state: dict[str, int] = {"starts": 0, "joins": 0}
        self.subscription_ids: list[int] = []
        self.task_ids: list[int] = []
        self.tick_count = 0
        self.motd_index = 0
        self.event_counts: dict[str, int] = {}
        self.logged_event_types: set[str] = set()
        self.player_boss_bars: dict[str, BossBar] = {}
        self.player_boss_bar_tasks: dict[str, int] = {}
        self.player_boss_bar_steps: dict[str, int] = {}

    def on_load(self, host: PluginHost) -> None:
        """Save the typed host and prepare this plugin's private data path."""
        self.host = host
        self.server = Server(host)
        self.system = System(host)
        # Generated vanilla constants are typed strings. Every API below also
        # accepts a custom add-on ID such as "other_addon:custom_block".
        self.overworld = self.server.level("BedrockPlus", DimensionTypes.Overworld)
        self.reference_block = self.overworld.block(0, 64, 0, BlockTypes.Stone)
        self.reference_item = self.server.item_stack(ItemTypes.Diamond)
        self.data_path = self.server.data_directory
        self.state_path = self.data_path / "state.json"
        host.log("info", "EXAMPLE.LOAD", "Full API example loaded")

    def on_enable(self) -> None:
        """Load persistent data before BDS runtime services are registered."""
        self.data_path.mkdir(parents=True, exist_ok=True)
        if self.state_path.is_file():
            try:
                loaded = json.loads(self.state_path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.state["starts"] = int(loaded.get("starts", 0))
                    self.state["joins"] = int(loaded.get("joins", 0))
            except (OSError, ValueError, TypeError):
                self.host.log(
                    "warning",
                    "EXAMPLE.STATE_INVALID",
                    "Invalid state.json was ignored",
                    {"path": str(self.state_path)},
                )
        self.state["starts"] += 1
        self._save_state()
        self.host.log(
            "info",
            "EXAMPLE.ENABLE",
            "Full API example enabled",
            {"starts": str(self.state["starts"])},
        )

    def on_server_ready(self) -> None:
        """Register commands, live event listeners, and scheduled callbacks."""
        if not self.host.commands_available():
            raise RuntimeError("BedrockPlus command service is unavailable")
        if not self.host.events_available():
            raise RuntimeError("BedrockPlus event service is unavailable")
        if not self.host.scheduler_available():
            raise RuntimeError("BedrockPlus scheduler service is unavailable")

        # A native slash command with an alias and optional trailing text.
        self.host.register_command(
            "bpexample",
            self.on_example_command,
            description="Exercise the BedrockPlus Python API",
            aliases=["bpx"],
            overloads=[
                [],
                [
                    CommandArgument(
                        "action", "enum",
                        choices=(
                            "say", "tell", "as", "kick", "player",
                            "hide", "restore", "stats", "entities",
                            "scoreboard",
                        ),
                    ),
                    CommandArgument("value", "text", optional=True),
                ],
            ],
        )

        # The previous command demonstrates enum autocomplete; this one covers
        # every scalar and trailing-text argument type.
        self.host.register_command(
            "bptypes",
            self.on_types_command,
            description="Test int, number, string, and text arguments",
            overloads=[[
                CommandArgument("count", "int"),
                CommandArgument("ratio", "number"),
                CommandArgument("word", "string"),
                CommandArgument("message", "text"),
            ]],
        )

        # All callbacks receive concrete event classes. HIGH runs before normal
        # listeners. Use event.cancel() and typed mutable properties.
        self.subscription_ids.extend([
            self.host.subscribe_event("server.tick", self.on_tick),
            self.host.subscribe_event("player.login", self.on_player_login),
            self.host.subscribe_event("player.join", self.on_player_join),
            self.host.subscribe_event("player.quit", self.on_player_quit),
            self.host.subscribe_event("player.respawn", self.on_player_respawn),
            self.host.subscribe_event("player.death", self.on_player_death),
            self.host.subscribe_event("player.interact", self.on_player_interact),
            self.host.subscribe_event("player.toggle_sneak", self.on_player_toggle_sneak),
            self.host.subscribe_event("player.toggle_sprint", self.on_player_toggle_sprint),
            self.host.subscribe_event("player.kick", self.on_player_kick),
            self.host.subscribe_event("player.chat", self.on_player_chat),
            self.host.subscribe_event("player.move", self.on_player_move),
            self.host.subscribe_event("player.jump", self.on_player_jump),
            self.host.subscribe_event("block.break", self.on_block_break),
            self.host.subscribe_event("block.place", self.on_block_place),
            self.host.subscribe_event("server.list_ping", self.on_server_list_ping),
            self.host.subscribe_event(
                "player.command", self.on_player_command, EventPriority.HIGH
            ),
            self.host.subscribe_event(
                "server.command", self.on_server_command, EventPriority.HIGH
            ),
        ])

        # System uses Bedrock ticks (20 ticks = one second), returns task IDs,
        # and exposes both Pythonic and Script-API-style method names.
        self.task_ids.append(self.system.runTimeout(self.on_delayed_task, 20))
        self.task_ids.append(self.system.run(self.on_next_tick_task))
        self.task_ids.append(self.system.runJob(self.example_job()))
        # Rotate the text used by future server-list ping responses every five
        # seconds. The list-ping event itself remains the only place that edits
        # an individual response.
        self.task_ids.append(self.system.runInterval(self.rotate_motd, 100))

        # The low-level host remains useful for a finite repeating task.
        self.task_ids.append(
            self.host.schedule(
                self.on_repeating_task,
                delay_ms=2000,
                interval_ms=2000,
                runs=3,
            )
        )

        # Schedule then cancel a task to show explicit task cancellation.
        cancelled_id = self.system.runTimeout(self.on_cancelled_task, 1200)
        self.system.clearRun(cancelled_id)

        self.host.log(
            "info",
            "EXAMPLE.READY",
            "Try /bpexample, /bptypes, /bpday, and /bpblocked",
            {
                "server": self.server.name,
                "api": str(self.server.api_version),
                "online_players": str(self.server.online_player_count),
            },
        )
    def on_example_command(self, invocation: CommandInvocation) -> CommandResult:
        """Handle /bpexample and demonstrate server dispatch/policy APIs."""
        args = invocation.args
        if not args:
            return CommandResult.success(
                    "API example is active. Actions: say, tell, as, kick, player, "
                    "hide, restore, stats, entities, scoreboard. "
                    "Also try /bpday and /bpblocked."
            )

        action = str(args[0]).casefold()
        value = str(args[1]).strip() if len(args) > 1 else ""

        if action == "say":
            if not value:
                return CommandResult.failure("Usage: /bpexample say <text>")
            accepted = self.server.broadcast(f"&d[BedrockPlus example]&r {value}")
            return CommandResult(accepted, "Server command queued" if accepted else "Queue rejected")

        # Player actions use "player name|value" so names may contain spaces.
        if action in {"tell", "as", "kick"}:
            player_name, action_value = self._split_player_action(value)
            if not player_name:
                return CommandResult.failure(
                    f"Usage: /bpexample {action} <player>|<value>"
                )
            player = self.server.player(player_name)
            if action == "tell":
                accepted = bool(action_value) and player.send_message(action_value)
            elif action == "as":
                accepted = bool(action_value) and player.run_command(action_value)
            else:
                accepted = player.kick(action_value or "Kicked by the API example")
            return CommandResult(
                accepted, f"{action} queued for {player.display_name}"
            )

        if action == "player":
            # Syntax: /bpexample player <name>|<operation>|<value>
            # This keeps player names with spaces intact while one reference
            # command demonstrates the complete typed Player action surface.
            player_name, separator, remainder = value.partition("|")
            operation, operation_separator, operation_value = remainder.partition("|")
            if not separator or not operation.strip():
                return CommandResult.failure(
                    "Usage: /bpexample player <name>|<operation>|<value>"
                )
            # Native operations (including tags) require the authenticated
            # numeric session. Prefer the live registry; retain the copied-name
            # reference only for command-backed actions against offline input.
            player = (
                self.server.get_player(player_name.strip())
                or self.server.player(player_name.strip())
            )
            try:
                normalized_operation = operation.strip().casefold()
                if normalized_operation == "tag-list":
                    tags = player.scoreboard_tags
                    return CommandResult.success(
                        "Native tags: " + (", ".join(tags) if tags else "none")
                    )
                if normalized_operation == "tag-has":
                    present = player.has_tag(operation_value.strip())
                    return CommandResult.success(
                        f"Native tag {operation_value.strip()!r}: "
                        f"{'present' if present else 'absent'}"
                    )
                accepted = self._run_player_api_action(
                    player,
                    normalized_operation,
                    operation_value.strip() if operation_separator else "",
                )
            except (TypeError, ValueError, RuntimeError) as error:
                return CommandResult.failure(str(error), "EXAMPLE_PLAYER_ARGUMENT")
            return CommandResult(
                accepted,
                f"{operation.strip()} queued for {player.display_name}",
            )

        if action in {"hide", "restore"}:
            command_name = value.lstrip("/").split(" ", 1)[0]
            if not command_name:
                return CommandResult.failure(
                    f"Usage: /bpexample {action} <vanilla-command>"
                )
            changed = (
                self.host.hide_vanilla_command(command_name)
                if action == "hide"
                else self.host.restore_vanilla_command(command_name)
            )
            return CommandResult(changed, f"{action}: {command_name}")

        if action == "stats":
            observed = ", ".join(
                f"{name}={count}" for name, count in sorted(self.event_counts.items())
            ) or "none"
            return CommandResult.success(
                    f"starts={self.state['starts']}; joins={self.state['joins']}; "
                    f"source={invocation.source_name}; server={self.server.name}; "
                    f"api={self.server.api_version}; "
                    f"online={self.server.online_player_count}; "
                    f"observed_events={observed}"
            )

        if action == "entities":
            # This is a fresh, pointer-free copy of BDS's complete Level-owned
            # Actor set. It does not parse console output or run a command.
            entities = self.server.entities
            if not entities:
                return CommandResult.success("No live native entities are loaded")
            lines = [f"Live native entities: {len(entities)}"]
            for entity in entities[:10]:
                position = entity.position
                coordinates = (
                    "unavailable" if position is None else
                    f"{position.x:.2f}, {position.y:.2f}, {position.z:.2f}"
                )
                lines.append(
                    f"{entity.type_id} | runtime={entity.runtime_id} | "
                    f"dimension={entity.dimension_id} | position={coordinates}"
                )
            if len(entities) > 10:
                lines.append(f"... and {len(entities) - 10} more")
            return CommandResult.success("\n".join(lines))

        if action == "scoreboard":
            # Reacquire the immutable generation on every read. Mutating
            # methods run natively on the BDS tick thread; no vanilla command
            # is composed behind this API.
            board = self.server.scoreboard
            if not board.ready:
                return CommandResult.failure("Native scoreboard is not ready")
            lines = [
                f"Scoreboard generation: {board.generation}",
                f"Objectives: {len(board.objectives)}",
                f"Entries: {len(board.entries)}",
            ]
            for objective in board.objectives[:10]:
                lines.append(
                    f"{objective.name}: {objective.display_name} "
                    f"({len(objective.scores)} scores)"
                )
            return CommandResult.success("\n".join(lines))

        return CommandResult.failure(
            f"Unknown action: {action}", "EXAMPLE_UNKNOWN_ACTION"
        )

    def on_types_command(self, invocation: CommandInvocation) -> CommandResult:
        """Receive BDS-parsed int, float, one-token string, and remaining text."""
        count, ratio, word, message = invocation.args
        return CommandResult.success(
                f"count={int(count)}; ratio={float(ratio):g}; "
                f"word={word}; message={message}"
        )

    def on_tick(self, event: ServerTickEvent) -> None:
        """Observe the server-thread tick feed without flooding the log."""
        self.tick_count += 1
        self._observe_event("server.tick", {"sequence": str(event.sequence)})

    def on_player_join(self, event: PlayerJoinEvent) -> None:
        """Read native player fields and persist a join counter."""
        player = event.player
        self._observe_event("player.join", {"player": player.display_name})
        self.state["joins"] += 1
        self._save_state()
        # Initial spawn is still inside BDS's native lifecycle hook. Defer UI
        # work until the player is fully initialized on the client.
        def send_welcome() -> None:
            player.send_message("&aWelcome! &fThis message uses the Player object.")
            self._attach_boss_bar(player)

        self.task_ids.append(self.host.schedule(send_welcome, delay_ms=2000))
        if player.address is None:
            address = "unavailable (BDS did not provide an endpoint)"
        else:
            try:
                parsed_address = ip_address(player.address.host)
                scope = (
                    "local network"
                    if parsed_address.is_private
                    or parsed_address.is_loopback
                    or parsed_address.is_link_local
                    else "public network"
                )
            except ValueError:
                scope = "network endpoint"
            address = f"{player.address.host}:{player.address.port} ({scope})"
        connection_summary = "\n".join(
            (
                f"Session: {player.session_id}",
                f"XUID: {player.xuid or 'unavailable'}",
                f"Connection data: {'available' if player.connection is not None else 'unavailable'}",
                f"Address: {address}",
                f"Device ID: {player.device_id or 'unavailable'}",
                f"Device model: {player.device_model or 'unavailable'}",
                f"Device OS: {player.device_os or 'unavailable'}",
                f"Input: {player.input_mode or 'unavailable'}",
                f"Game version: {player.game_version or 'unavailable'}",
                f"Locale: {player.locale or 'unavailable'}",
                f"Ping: {player.ping_ms if player.ping_ms is not None else 'unavailable'} ms",
            )
        )
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_JOIN",
            f"{player.display_name} joined\n{connection_summary}",
            {
                "session": player.session_id,
                "connection_available": str(player.connection is not None),
                "ping_ms": str(player.ping_ms) if player.ping_ms is not None else "",
                "device_model": player.device_model,
                "device_os": player.device_os,
                "input_mode": player.input_mode,
                "game_version": player.game_version,
                "locale": player.locale,
                "address": address,
                "device_id": player.device_id,
                # This comes from the authenticated native online registry,
                # not from parsing the `list` command output.
                "online_players": str(self.server.online_player_count),
            },
        )
        registry = self.server.item_registry
        if registry.ready:
            diamond = registry.get(ItemTypes.Diamond)
            self.host.log(
                "info",
                "EXAMPLE.ITEM_REGISTRY",
                "Native item registry is ready\n"
                f"Generation: {registry.generation}\n"
                f"Items: {len(registry.entries)}\n"
                f"Custom items: {len(registry.custom_entries)}\n"
                f"Diamond runtime ID: {diamond.runtime_id if diamond else 'unavailable'}",
            )

    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        """Observe native departure data without inventing a missing reason."""
        player = event.player
        # The native disconnect path already detaches this session. Destroying
        # the now-empty logical bars keeps the example's owner state bounded.
        bar = self.player_boss_bars.pop(player.session_id, None)
        if bar is not None:
            bar.destroy()
        task = self.player_boss_bar_tasks.pop(player.session_id, None)
        if task is not None:
            self.host.cancel_task(task)
        self.player_boss_bar_steps.pop(player.session_id, None)
        self._observe_event("player.quit", {"player": player.display_name})
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_QUIT",
            f"{player.display_name} left",
            {
                "session": player.session_id,
                "reason": event.reason or "unavailable",
                "reason_code": (
                    str(event.reason_code)
                    if event.reason_code is not None
                    else "unavailable"
                ),
            },
        )

    def on_player_respawn(self, event: PlayerRespawnEvent) -> None:
        """Observe a completed vanilla respawn without a guessed location."""
        player = event.player
        self._observe_event("player.respawn", {"player": player.display_name})

        def send_respawn_message() -> None:
            player.send_message("&aRespawn complete.")

        self.task_ids.append(self.system.run(send_respawn_message))

    def on_player_death(self, event: PlayerDeathEvent) -> None:
        """Observe a completed native death without guessing its cause."""
        player = event.player
        self._observe_event("player.death", {"player": player.display_name})
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_DEATH",
            f"{player.display_name} died",
        )

    def on_player_interact(self, event: PlayerInteractEvent) -> None:
        """Observe the real left-click-air input before vanilla handling."""
        self._observe_event(
            "player.interact",
            {"player": event.player.display_name, "action": event.action},
        )
        # event.cancel() clears only this interaction flag; movement from the
        # same authenticated input packet continues normally.

    def on_player_toggle_sneak(self, event: PlayerToggleSneakEvent) -> None:
        """Observe a real native sneaking start/stop transition."""
        self._observe_event(
            "player.toggle_sneak",
            {
                "player": event.player.display_name,
                "sneaking": str(event.is_sneaking).lower(),
            },
        )

    def on_player_toggle_sprint(self, event: PlayerToggleSprintEvent) -> None:
        """Observe a real native sprinting start/stop transition."""
        self._observe_event(
            "player.toggle_sprint",
            {
                "player": event.player.display_name,
                "sprinting": str(event.is_sprinting).lower(),
            },
        )

    def on_player_login(self, event: PlayerLoginEvent) -> None:
        """Inspect authenticated connection data before the player spawns."""
        player = event.player
        self._observe_event("player.login", {"player": player.display_name})
        self.host.log(
            "debug",
            "EXAMPLE.PLAYER_LOGIN",
            f"Login accepted for {player.display_name}",
            {"device_model": player.device_model},
        )
        # A real access plugin can set event.kick_message and call event.cancel().

    def on_player_kick(self, event: PlayerKickEvent) -> None:
        """Observe, cancel, or rewrite a native disconnect reason."""
        self._observe_event("player.kick", {"player": event.player.display_name})
        self.host.log(
            "debug",
            "EXAMPLE.PLAYER_KICK",
            f"{event.player.display_name}: {event.reason}",
            {
                "reason_code": (
                    str(event.reason_code)
                    if event.reason_code is not None
                    else "unavailable"
                )
            },
        )
        # The reason is mutable: event.reason = "A clearer reason"

    def on_player_chat(self, event: PlayerChatEvent) -> None:
        """Cancel a sample marker or rewrite a chat message before BDS handles it."""
        self._observe_event(
            "player.chat",
            {"player": event.player.display_name, "length": str(len(event.message))},
        )
        message = event.message
        if message.casefold() == "!cancel-example":
            event.cancel()
        elif message.startswith("!green "):
            event.message = "§a" + message[7:]

    def on_player_move(self, event: PlayerMoveEvent) -> None:
        """Read typed locations; cancelling restores the accepted position."""
        destination = event.to_location
        self._observe_event(
            "player.move",
            {
                "player": event.player.display_name,
                "dimension": destination.dimension_id or "unavailable",
                "x": f"{destination.position.x:g}",
                "y": f"{destination.position.y:g}",
                "z": f"{destination.position.z:g}",
            },
        )

    def on_player_jump(self, event: PlayerJumpEvent) -> None:
        """Observe or cancel the rising-edge jump input."""
        self._observe_event(
            "player.jump", {"player": event.player.display_name}
        )
        # event.cancel() prevents this jump input.

    def on_block_break(self, event: BlockBreakEvent) -> None:
        """Handle the pre-action block-break request."""
        block: Block = event.block
        position = block.position
        self._observe_event(
            "block.break",
            {
                "player": event.player.display_name,
                "x": f"{position.x:g}",
                "y": f"{position.y:g}",
                "z": f"{position.z:g}",
            },
        )
        # block.type_id and block.level are None when the request hook did not
        # supply an authoritative permutation or dimension. The SDK does not
        # substitute minecraft:air or the overworld.
        # event.cancel() prevents BDS from handling the request.

    def on_block_place(self, event: BlockPlaceEvent) -> None:
        """Handle the pre-action item-use-on-block request."""
        position = event.block.position
        self._observe_event(
            "block.place",
            {
                "player": event.player.display_name,
                "face": str(event.block_face),
                "x": f"{position.x:g}",
                "y": f"{position.y:g}",
                "z": f"{position.z:g}",
            },
        )
        # event.cancel() prevents BDS from handling the request.

    def on_server_list_ping(self, event: ServerListPingEvent) -> None:
        """Customize MOTD and advertised counts for this list response."""
        client = event.client_address
        self._observe_event(
            "server.list_ping",
            {
                "online": str(event.online_players),
                "maximum": str(event.maximum_players),
                "address": (
                    f"{client.host}:{client.port}" if client is not None else "unavailable"
                ),
            },
        )
        event.motd = self.motd_messages[self.motd_index]
        event.secondary_motd = self.motd_messages[
            (self.motd_index + 1) % len(self.motd_messages)
        ]
        # Read the real counts without replacing them with demonstration data.
        _real_online_players = event.online_players
        _real_maximum_players = event.maximum_players
        # event.cancel() suppresses this one response.

    def on_player_command(self, event: PlayerCommandEvent) -> None:
        """Cancel /bpblocked and run /bpday through the server command queue."""
        self._observe_event(
            "player.command", {"player": event.player.display_name}
        )
        command = event.command.lstrip("/").casefold()
        if command == "bpblocked":
            event.cancel()
        elif command == "bpday":
            # Rewriting to `time` would retain the player's vanilla permission
            # level. Cancel the player request and dispatch as server instead.
            event.cancel()
            self.server.dispatch_command("time set day")

    def on_server_command(self, event: ServerCommandEvent) -> None:
        """Apply the same control model to commands entered in the console."""
        self._observe_event("server.command")
        command = event.command.lstrip("/").casefold()
        if command == "bpblockedserver":
            event.cancel()
        elif command == "bpnight":
            event.command = "time set night"

    def on_delayed_task(self) -> None:
        self.host.log("info", "EXAMPLE.DELAYED_TASK", "One-shot task ran")

    def on_next_tick_task(self) -> None:
        self.host.log("debug", "EXAMPLE.NEXT_TICK_TASK", "system.run task ran")

    def example_job(self) -> Iterator[None]:
        """Yield three times; System advances this generator once per tick."""
        for step in range(3):
            self.host.log("debug", "EXAMPLE.JOB_STEP", f"Job step {step + 1}")
            yield

    def on_repeating_task(self) -> None:
        self.host.log("debug", "EXAMPLE.REPEATING_TASK", "Repeating task ran")

    def rotate_motd(self) -> None:
        """Select the message used for the next server-list ping response."""
        self.motd_index = (self.motd_index + 1) % len(self.motd_messages)

    def on_cancelled_task(self) -> None:
        # This must never execute because it is cancelled in on_server_ready.
        self.host.log("error", "EXAMPLE.CANCEL_FAILED", "Cancelled task executed")

    def on_server_stopping(self) -> None:
        """Explicitly release owned resources before host teardown."""
        for task_id in self.task_ids:
            self.system.clearRun(task_id)
        self.task_ids.clear()

        for task_id in self.player_boss_bar_tasks.values():
            self.host.cancel_task(task_id)
        self.player_boss_bar_tasks.clear()
        self.player_boss_bar_steps.clear()

        for bar in self.player_boss_bars.values():
            bar.destroy()
        self.player_boss_bars.clear()

        for subscription_id in self.subscription_ids:
            self.host.unsubscribe_event(subscription_id)
        self.subscription_ids.clear()

        self.host.unregister_command("bpexample")
        self.host.unregister_command("bptypes")
        self.host.log("info", "EXAMPLE.STOPPING", "Example resources released")

    def on_disable(self) -> None:
        self._save_state()
        self.host.log("info", "EXAMPLE.DISABLE", "Full API example disabled")

    def on_unload(self) -> None:
        """No host calls are made after this final lifecycle callback."""

    def _save_state(self) -> None:
        # Keep the reference compatible with Windows security scanners and
        # backup tools that can briefly hold newly-created temporary files.
        self.state_path.write_text(
            json.dumps(self.state, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    def _attach_boss_bar(self, player: Player) -> None:
        """Attach one native, animated bar after the client finishes spawning."""
        session = player.session_id
        old_task = self.player_boss_bar_tasks.pop(session, None)
        if old_task is not None:
            self.host.cancel_task(old_task)
        old_bar = self.player_boss_bars.pop(session, None)
        if old_bar is not None:
            old_bar.destroy()

        bar = self.server.create_boss_bar(
            "BedrockPlus BossBar works: 100%",
            BossBarColor.PURPLE,
            BossBarStyle.SEGMENTED_10,
            1.0,
        )
        try:
            bar.add_player(player)
        except BossBarError as error:
            bar.destroy()
            self.host.log(
                "warning",
                "EXAMPLE.BOSSBAR_ATTACH_SKIPPED",
                f"Player left before the BossBar could be attached: {error}",
                {"player": player.display_name, "session": session},
            )
            return

        self.player_boss_bars[session] = bar
        self.player_boss_bar_steps[session] = 10
        self.player_boss_bar_tasks[session] = self.host.schedule(
            lambda: self._animate_boss_bar(session),
            interval_ms=1000,
            runs=0,
        )
        self.host.log(
            "info",
            "EXAMPLE.BOSSBAR_ATTACHED",
            "One animated native BossBar attached",
            {"player": player.display_name, "bar": str(bar.id)},
        )

    def _animate_boss_bar(self, session: str) -> None:
        """Demonstrate live title, progress, color, and style updates."""
        bar = self.player_boss_bars.get(session)
        if bar is None:
            return
        step = (self.player_boss_bar_steps.get(session, 10) - 1) % 11
        self.player_boss_bar_steps[session] = step
        try:
            bar.set_progress(step / 10.0)
            bar.set_title(f"BedrockPlus BossBar works: {step * 10}%")
            if step == 10:
                bar.set_color(BossBarColor.PURPLE)
                bar.set_style(BossBarStyle.SEGMENTED_10)
            elif step == 5:
                bar.set_color(BossBarColor.GREEN)
                bar.set_style(BossBarStyle.SOLID)
        except BossBarError as error:
            task = self.player_boss_bar_tasks.pop(session, None)
            if task is not None:
                self.host.cancel_task(task)
            self.host.log(
                "error",
                "EXAMPLE.BOSSBAR_UPDATE_FAILED",
                f"Native BossBar update failed: {error}",
                {"session": session},
            )

    def _observe_event(
        self, event_name: str, fields: dict[str, str] | None = None
    ) -> None:
        """Count every real callback and log the first occurrence only."""
        self.event_counts[event_name] = self.event_counts.get(event_name, 0) + 1
        if event_name in self.logged_event_types:
            return
        self.logged_event_types.add(event_name)
        self.host.log(
            "info",
            "EXAMPLE.EVENT_OBSERVED",
            f"Observed native {event_name} event",
            fields or {},
        )

    @staticmethod
    def _split_player_action(value: str) -> tuple[str, str]:
        player_name, separator, action_value = value.partition("|")
        return player_name.strip(), action_value.strip() if separator else ""

    @staticmethod
    def _run_player_api_action(
        player: Player,
        operation: str,
        value: str,
    ) -> bool:
        """Exercise typed, validated Player operations from one test command.

        Examples:
          /bpexample player Steve|gamemode|creative
          /bpexample player Steve|effect|minecraft:speed,200,1
          /bpexample player Steve|rotate|0,180

        These methods return command-queue acceptance. They intentionally do
        not claim that BDS completed a command after it entered the queue.
        """
        if operation == "message":
            return player.send_message(value)
        if operation == "error":
            return player.send_error_message(value)
        if operation == "actionbar":
            return player.send_action_bar(value)
        if operation == "title":
            title, separator, subtitle = value.partition(",")
            return player.send_title(title.strip(), subtitle.strip() if separator else "")
        if operation == "title-clear":
            return player.clear_title()
        if operation == "title-reset":
            return player.reset_title()
        if operation == "command":
            return player.perform_command(value)
        if operation == "transfer":
            host, separator, port = value.partition(",")
            return player.transfer(host.strip(), int(port) if separator else 19132)
        if operation == "operator":
            state = value.strip().casefold()
            if state not in {"true", "false"}:
                raise ValueError("operator value must be true or false")
            return player.set_operator(state == "true")
        if operation == "gamemode":
            return player.set_game_mode(GameMode(value.casefold()))
        if operation == "xp":
            return player.add_experience(int(value))
        if operation == "levels":
            return player.add_levels(int(value))
        if operation == "spawn":
            return player.set_spawn_point(player.location)
        if operation == "spawn-clear":
            return player.clear_spawn_point()
        if operation == "inventory-clear":
            item_id, separator, count = value.partition(",")
            return (
                player.clear_inventory(item_id.strip(), max_count=int(count))
                if item_id.strip()
                else player.clear_inventory()
            )
        if operation == "tag-add":
            return player.add_tag(value)
        if operation == "tag-remove":
            return player.remove_tag(value)
        if operation == "effect":
            parts = [part.strip() for part in value.split(",")]
            if len(parts) not in {2, 3}:
                raise ValueError("effect value must be id,duration_ticks[,amplifier]")
            return player.add_effect(
                parts[0],
                int(parts[1]),
                int(parts[2]) if len(parts) == 3 else 0,
            )
        if operation == "effect-clear":
            return player.remove_effect(value or None)
        if operation == "damage":
            amount, separator, cause = value.partition(",")
            return player.apply_damage(int(amount), cause.strip() if separator else None)
        if operation == "kill":
            return player.kill()
        if operation == "sound":
            return player.play_sound(value)
        if operation == "sound-stop":
            return player.stop_sound(value or None)
        if operation == "input":
            permission, separator, state = value.partition(",")
            if not separator or state.strip().casefold() not in {"true", "false"}:
                raise ValueError("input value must be permission,true|false")
            return player.set_input_permission(
                InputPermission(permission.strip().casefold()),
                state.strip().casefold() == "true",
            )
        if operation == "camera-shake":
            intensity, seconds, kind = (part.strip() for part in value.split(",", 2))
            return player.add_camera_shake(
                float(intensity), float(seconds), CameraShakeType(kind.casefold())
            )
        if operation == "camera-stop":
            return player.stop_camera_shake()
        if operation == "camera":
            preset = value.strip() or CameraPresetTypes.FirstPerson
            return player.set_camera(preset)
        if operation == "camera-clear":
            return player.clear_camera()
        if operation == "rotate":
            pitch, yaw = (float(part.strip()) for part in value.split(",", 1))
            return player.set_rotation(Vector2(pitch, yaw))
        if operation == "look-at":
            x, y, z = (float(part.strip()) for part in value.split(",", 2))
            return player.look_at(Vector3(x, y, z))
        if operation == "event":
            return player.trigger_event(value)
        if operation == "animation":
            return player.play_animation(value)
        if operation == "give":
            item_id, separator, count = value.partition(",")
            return player.give(
                ItemStack(item_id.strip(), int(count) if separator else 1)
            )
        raise ValueError(
            "operation must be message, error, actionbar, title, title-clear, "
            "title-reset, command, transfer, operator, gamemode, xp, levels, spawn, "
            "spawn-clear, inventory-clear, tag-list, tag-has, tag-add, tag-remove, effect, "
            "effect-clear, damage, kill, sound, sound-stop, input, camera-shake, "
            "camera-stop, camera, camera-clear, rotate, look-at, event, animation, or give"
        )
