#include <bedrockplus/sdk/plugin.hpp>

#include <array>
#include <atomic>
#include <cstdint>
#include <fstream>
#include <map>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>
#include <unordered_set>
#include <variant>
#include <vector>

namespace {

using bedrockplus::sdk::CommandArgument;
using bedrockplus::sdk::CommandArgumentType;
using bedrockplus::sdk::CommandDefinition;
using bedrockplus::sdk::CommandInvocation;
using bedrockplus::sdk::CommandOverload;
using bedrockplus::sdk::CommandResponse;
using bedrockplus::sdk::BlockBreakEvent;
using bedrockplus::sdk::BlockPlaceEvent;
using bedrockplus::sdk::CameraShakeType;
using bedrockplus::sdk::EventPriority;
using bedrockplus::sdk::GameMode;
using bedrockplus::sdk::InputPermission;
using bedrockplus::sdk::ItemStack;
using bedrockplus::sdk::PlayerSnapshot;
using bedrockplus::sdk::Player;
using bedrockplus::sdk::PlayerJoinEvent;
using bedrockplus::sdk::PlayerInteractEvent;
using bedrockplus::sdk::PlayerChatEvent;
using bedrockplus::sdk::PlayerCommandEvent;
using bedrockplus::sdk::PlayerDeathEvent;
using bedrockplus::sdk::PlayerKickEvent;
using bedrockplus::sdk::PlayerLoginEvent;
using bedrockplus::sdk::PlayerJumpEvent;
using bedrockplus::sdk::PlayerMoveEvent;
using bedrockplus::sdk::PlayerQuitEvent;
using bedrockplus::sdk::PlayerRespawnEvent;
using bedrockplus::sdk::PlayerToggleSneakEvent;
using bedrockplus::sdk::PlayerToggleSprintEvent;
using bedrockplus::sdk::Plugin;
using bedrockplus::sdk::ServerCommandEvent;
using bedrockplus::sdk::ServerListPingEvent;
using bedrockplus::sdk::ServerTickEvent;
using bedrockplus::sdk::Vector3;
using bedrockplus::sdk::Vector2;
using bedrockplus::vanilla::BlockTypes;
using bedrockplus::vanilla::CameraPresetTypes;
using bedrockplus::vanilla::DimensionTypes;
using bedrockplus::vanilla::ItemTypes;

static_assert(BlockTypes::Stone.value() == "minecraft:stone");
static_assert(DimensionTypes::Overworld.value() == "minecraft:overworld");
static_assert(ItemTypes::Diamond.value() == "minecraft:diamond");

[[nodiscard]] std::string value_as_text(const CommandInvocation& invocation, const std::size_t index) {
    if (index >= invocation.values.size()) {
        return {};
    }
    if (const auto* text = std::get_if<std::string>(&invocation.values[index])) {
        return *text;
    }
    if (const auto* integer = std::get_if<std::int64_t>(&invocation.values[index])) {
        return std::to_string(*integer);
    }
    return std::to_string(std::get<double>(invocation.values[index]));
}

class FullCppPlugin final : public Plugin {
public:
    using Plugin::Plugin;

    bp_status on_load() override {
        logger().log(BP_LOG_INFO, "Full C++ API example loaded", "EXAMPLE.CPP.LOAD");
        return BP_STATUS_OK;
    }

    bp_status on_enable() override {
        data_path_ = data_directory();
        std::filesystem::create_directories(data_path_);
        std::ofstream{data_path_ / "enabled.txt", std::ios::trunc} << "enabled\n";
        logger().log(BP_LOG_INFO, "Full C++ API example enabled", "EXAMPLE.CPP.ENABLE");
        return BP_STATUS_OK;
    }

    void on_server_ready() override {
        register_commands();
        subscribe_events();
        schedule_tasks();
        logger().log(BP_LOG_INFO,
                     "Try /bpcppexample, /bpcpptypes, /bpcppday, and /bpcppblocked",
                     "EXAMPLE.CPP.READY");
    }

    void on_server_stopping() override {
        for (const auto task : task_ids_) {
            static_cast<void>(scheduler().clear_run(task));
        }
        task_ids_.clear();
        for (const auto listener : listener_ids_) {
            static_cast<void>(events().unsubscribe(listener));
        }
        listener_ids_.clear();
        static_cast<void>(commands().unregister_command("bpcppexample"));
        static_cast<void>(commands().unregister_command("bpcpptypes"));
        for (const auto& command : hidden_vanilla_commands_) {
            static_cast<void>(commands().restore_vanilla_command(command));
        }
        hidden_vanilla_commands_.clear();
        logger().log(BP_LOG_INFO, "C++ example resources released", "EXAMPLE.CPP.STOPPING");
    }

    void on_disable() override {
        logger().log(BP_LOG_INFO, "Full C++ API example disabled", "EXAMPLE.CPP.DISABLE");
    }

    void on_unload() override {
        // The host must not be called after this callback returns.
    }

private:
    static constexpr std::array<std::string_view, 5> motd_messages_{
        "BedrockPlus C++ API example",
        "Typed native plugins are running",
        "Cancellable events are enabled",
        "Native slash commands are enabled",
        "Scheduled tasks are active",
    };

    void register_commands() {
        CommandDefinition example;
        example.name = "bpcppexample";
        example.description = "Exercise the BedrockPlus C++ API";
        example.permission = "";
        example.aliases = {"bpcpp"};
        example.overloads = {
            CommandOverload{},
            CommandOverload{{
                CommandArgument{"action", CommandArgumentType::enumeration, false,
                                {"say", "player", "hide", "restore", "stats", "entities",
                                 "scoreboard"}},
                CommandArgument{"value", CommandArgumentType::text, true, {}},
            }},
        };
        commands().register_command(example, [this](const CommandInvocation& invocation) {
            if (invocation.values.empty()) {
                return CommandResponse{true,
                    "Actions: say, player, hide, restore, stats, entities, scoreboard", {}};
            }
            const auto action = value_as_text(invocation, 0);
            const auto value = value_as_text(invocation, 1);
            if (action == "say") {
                const auto accepted = !value.empty() && commands().dispatch_server_command("say " + value);
                return CommandResponse{accepted, accepted ? "Server command queued" : "Queue rejected", {}};
            }
            if (action == "player") {
                // Syntax: /bpcppexample player <name>|<operation>|<value>
                const auto first = value.find('|');
                const auto second = first == std::string::npos
                    ? std::string::npos : value.find('|', first + 1);
                if (first == std::string::npos || first == 0) {
                    return CommandResponse{false,
                        "Usage: /bpcppexample player <name>|<operation>|<value>",
                        "EXAMPLE_PLAYER_ARGUMENT"};
                }
                const auto name = value.substr(0, first);
                const auto operation = value.substr(
                    first + 1,
                    second == std::string::npos ? std::string::npos : second - first - 1);
                const auto argument = second == std::string::npos ? std::string{} : value.substr(second + 1);
                try {
                    Player player{commands(), PlayerSnapshot{name, "", "", "", std::nullopt, std::nullopt}};
                    const auto accepted = run_player_action(player, operation, argument);
                    return CommandResponse{accepted, operation + " queued for " + player.display_name(), {}};
                } catch (const std::exception& error) {
                    return CommandResponse{false, error.what(), "EXAMPLE_PLAYER_ARGUMENT"};
                }
            }
            if (action == "hide" || action == "restore") {
                const auto changed = !value.empty() && (action == "hide"
                    ? commands().hide_vanilla_command(value)
                    : commands().restore_vanilla_command(value));
                if (changed && action == "hide") {
                    hidden_vanilla_commands_.insert(value);
                } else if (changed) {
                    hidden_vanilla_commands_.erase(value);
                }
                return CommandResponse{changed, action + ": " + value, {}};
            }
            if (action == "stats") {
                return CommandResponse{true,
                    "ticks=" + std::to_string(tick_count_) + "; source=" +
                        std::string{invocation.source_name} + "; observed_events=" +
                        event_count_summary(),
                    {}};
            }
            if (action == "entities") {
                // This reads the complete verified Level-owned Actor set. The
                // SDK receives only pointer-free copies of native fields.
                const auto entities = server().entities();
                std::ostringstream output;
                output << "Live native entities: " << entities.size();
                const auto shown = std::min<std::size_t>(entities.size(), 10U);
                for (std::size_t index = 0; index < shown; ++index) {
                    const auto& entity = entities[index];
                    const auto& position = entity.position();
                    output << '\n' << entity.type_id()
                           << " | runtime=" << entity.runtime_id()
                           << " | dimension=" << entity.dimension_id()
                           << " | position=" << position.x << ", "
                           << position.y << ", " << position.z;
                }
                if (entities.size() > shown) {
                    output << "\n... and " << (entities.size() - shown) << " more";
                }
                return CommandResponse{true, output.str(), {}};
            }
            if (action == "scoreboard") {
                // This is a pointer-free native snapshot. Mutations exposed
                // by Server are executed on the authenticated BDS tick thread,
                // never by composing a vanilla scoreboard command.
                const auto board = server().scoreboard();
                std::ostringstream output;
                output << "Scoreboard generation: " << board.generation
                       << "\nObjectives: " << board.objectives.size();
                for (std::size_t index{};
                     index < std::min<std::size_t>(board.objectives.size(), 10U);
                     ++index) {
                    const auto& objective = board.objectives[index];
                    output << '\n' << objective.name << ": "
                           << objective.display_name << " ("
                           << objective.scores.size() << " scores)";
                }
                return CommandResponse{board.ready, output.str(), {}};
            }
            return CommandResponse{false, "Unknown action: " + action, "EXAMPLE_UNKNOWN_ACTION"};
        });

        CommandDefinition types;
        types.name = "bpcpptypes";
        types.description = "Test all native argument types";
        types.permission = "";
        types.overloads = {CommandOverload{{
            CommandArgument{"count", CommandArgumentType::integer, false, {}},
            CommandArgument{"ratio", CommandArgumentType::real, false, {}},
            CommandArgument{"word", CommandArgumentType::string, false, {}},
            CommandArgument{"message", CommandArgumentType::text, false, {}},
        }}};
        commands().register_command(types, [](const CommandInvocation& invocation) {
            return CommandResponse{true,
                "count=" + value_as_text(invocation, 0) + "; ratio=" + value_as_text(invocation, 1) +
                    "; word=" + value_as_text(invocation, 2) + "; message=" + value_as_text(invocation, 3),
                {}};
        });
    }

    void subscribe_events() {
        listener_ids_.push_back(events().subscribe<ServerTickEvent>([this](const ServerTickEvent& event) {
            ++tick_count_;
            if (record_event("server.tick")) {
                logger().log(BP_LOG_INFO, "Observed native server.tick event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"sequence", std::to_string(event.sequence())}});
            }
        }));
        listener_ids_.push_back(events().subscribe<PlayerJoinEvent>(
            [this](const PlayerJoinEvent& event) {
            auto snapshot = event.player();
            static_cast<void>(record_event("player.join"));
            logger().log(BP_LOG_INFO, snapshot.name + " joined", "EXAMPLE.CPP.PLAYER_JOIN",
                         {{"session", snapshot.session_id}, {"xuid", snapshot.xuid},
                          {"online_players", std::to_string(server().online_player_count())}});
            if (server().item_registry_available()) {
                const auto registry = server().item_registry();
                if (registry.ready) {
                    const auto* diamond = registry.find(ItemTypes::Diamond.value());
                    std::size_t custom_items{};
                    for (const auto& item : registry.entries) {
                        if (!item.type_id.starts_with("minecraft:")) ++custom_items;
                    }
                    logger().log(BP_LOG_INFO,
                        "Native item registry is ready\nGeneration: " +
                            std::to_string(registry.generation) + "\nItems: " +
                            std::to_string(registry.entries.size()) + "\nCustom items: " +
                            std::to_string(custom_items) + "\nDiamond runtime ID: " +
                            (diamond ? std::to_string(diamond->runtime_id) : "unavailable"),
                        "EXAMPLE.CPP.ITEM_REGISTRY");
                }
            }
            // Initial spawn is still inside the native BDS hook. Defer the
            // command-backed welcome action to avoid re-entering BDS.
            task_ids_.push_back(scheduler().run([this, session = snapshot.session_id] {
                if (auto player = server().get_player(session)) {
                    static_cast<void>(player->send_message(
                        "&aWelcome from the typed C++ Player API!"));
                }
            }));
        }));
        listener_ids_.push_back(events().subscribe<PlayerQuitEvent>(
            [this](const PlayerQuitEvent& event) {
            const auto snapshot = event.player();
            static_cast<void>(record_event("player.quit"));
            const auto reason = event.reason();
            logger().log(BP_LOG_INFO, snapshot.name + " left", "EXAMPLE.CPP.PLAYER_QUIT",
                         {{"reason", reason ? std::string{*reason} : "unavailable"},
                          {"reason_code", event.reason_code()
                              ? std::to_string(*event.reason_code()) : "unavailable"}});
        }));
        listener_ids_.push_back(events().subscribe<PlayerRespawnEvent>(
            [this](const PlayerRespawnEvent& event) {
            auto snapshot = event.player();
            static_cast<void>(record_event("player.respawn"));
            logger().log(BP_LOG_INFO, snapshot.name + " respawned",
                         "EXAMPLE.CPP.PLAYER_RESPAWN");
            task_ids_.push_back(scheduler().run([this, snapshot = std::move(snapshot)]() mutable {
                Player player{commands(), std::move(snapshot)};
                static_cast<void>(player.send_message("&aRespawn complete."));
            }));
        }));
        listener_ids_.push_back(events().subscribe<PlayerDeathEvent>(
            [this](const PlayerDeathEvent& event) {
            const auto snapshot = event.player();
            static_cast<void>(record_event("player.death"));
            logger().log(BP_LOG_INFO, snapshot.name + " died",
                         "EXAMPLE.CPP.PLAYER_DEATH");
        }));
        listener_ids_.push_back(events().subscribe<PlayerInteractEvent>(
            [this](const PlayerInteractEvent& event) {
            if (record_event("player.interact")) {
                logger().log(BP_LOG_INFO, "Observed native player.interact event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"action", std::string{event.action()}}});
            }
            // event.cancel() clears only the interaction input flag.
        }));
        listener_ids_.push_back(events().subscribe<PlayerToggleSneakEvent>(
            [this](const PlayerToggleSneakEvent& event) {
            if (record_event("player.toggle_sneak")) {
                logger().log(BP_LOG_INFO, "Observed native player.toggle_sneak event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"sneaking", event.is_sneaking() ? "true" : "false"}});
            }
        }));
        listener_ids_.push_back(events().subscribe<PlayerToggleSprintEvent>(
            [this](const PlayerToggleSprintEvent& event) {
            if (record_event("player.toggle_sprint")) {
                logger().log(BP_LOG_INFO, "Observed native player.toggle_sprint event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"sprinting", event.is_sprinting() ? "true" : "false"}});
            }
        }));
        listener_ids_.push_back(events().subscribe<PlayerLoginEvent>(
            [this](const PlayerLoginEvent& event) {
            const auto snapshot = event.player();
            static_cast<void>(record_event("player.login"));
            logger().log(BP_LOG_DEBUG,
                         std::string{"Login accepted for "} + snapshot.name,
                         "EXAMPLE.CPP.PLAYER_LOGIN",
                         {{"device_model", snapshot.connection
                             ? snapshot.connection->device_model : std::string{}}});
            // A real access plugin can call event.cancel() here.
        }));
        listener_ids_.push_back(events().subscribe<PlayerKickEvent>(
            [this](const PlayerKickEvent& event) {
            const auto snapshot = event.player();
            static_cast<void>(record_event("player.kick"));
            logger().log(BP_LOG_DEBUG,
                         snapshot.name + ": " + std::string{event.reason()},
                         "EXAMPLE.CPP.PLAYER_KICK",
                         {{"reason_code", event.reason_code()
                             ? std::to_string(*event.reason_code()) : "unavailable"}});
            // The reason is mutable: event.set_reason("A clearer reason").
        }));
        listener_ids_.push_back(events().subscribe<PlayerChatEvent>([this](const PlayerChatEvent& event) {
            const auto message = event.message();
            if (record_event("player.chat")) {
                logger().log(BP_LOG_INFO, "Observed native player.chat event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"length", std::to_string(message.size())}});
            }
            if (message == "!cancel-example") {
                static_cast<void>(event.cancel());
            } else if (message.starts_with("!green ")) {
                static_cast<void>(event.set_message(std::string{"\xC2\xA7" "a"} +
                                                     std::string{message.substr(7)}));
            }
        }, EventPriority::early));
        listener_ids_.push_back(events().subscribe<PlayerMoveEvent>([this](const PlayerMoveEvent& event) {
            // A plugin may inspect typed locations, call set_to_location(), or
            // cancel to restore the previous accepted packet position.
            const auto destination = event.to_location();
            if (record_event("player.move")) {
                logger().log(BP_LOG_INFO, "Observed native player.move event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"dimension", destination.dimension_id.value_or("unavailable")},
                              {"x", std::to_string(destination.position.x)},
                              {"y", std::to_string(destination.position.y)},
                              {"z", std::to_string(destination.position.z)}});
            }
        }));
        listener_ids_.push_back(events().subscribe<PlayerJumpEvent>([this](const PlayerJumpEvent& event) {
            // Calling event.cancel() here prevents this jump input.
            if (record_event("player.jump")) {
                logger().log(BP_LOG_INFO, "Observed native player.jump event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name}});
            }
        }));
        listener_ids_.push_back(events().subscribe<BlockBreakEvent>([this](const BlockBreakEvent& event) {
            // Pre-action request with a typed copied block snapshot.
            const auto block = event.block();
            if (record_event("block.break")) {
                logger().log(BP_LOG_INFO, "Observed native block.break event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"x", std::to_string(block.location.position.x)},
                              {"y", std::to_string(block.location.position.y)},
                              {"z", std::to_string(block.location.position.z)}});
            }
        }));
        listener_ids_.push_back(events().subscribe<BlockPlaceEvent>([this](const BlockPlaceEvent& event) {
            // Calling event.cancel() prevents BDS from handling this request.
            const auto block = event.block();
            if (record_event("block.place")) {
                logger().log(BP_LOG_INFO, "Observed native block.place event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name},
                              {"face", std::to_string(event.block_face())},
                              {"x", std::to_string(block.location.position.x)},
                              {"y", std::to_string(block.location.position.y)},
                              {"z", std::to_string(block.location.position.z)}});
            }
        }));
        listener_ids_.push_back(events().subscribe<ServerListPingEvent>([this](const ServerListPingEvent& event) {
            // MOTD can be changed for this one RakNet response without editing
            // server.properties. Real player counts remain unchanged.
            const auto index = motd_index_.load(std::memory_order_relaxed);
            if (record_event("server.list_ping")) {
                const auto client = event.client_address();
                logger().log(BP_LOG_INFO, "Observed native server.list_ping event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"online", std::to_string(event.online_players())},
                              {"maximum", std::to_string(event.maximum_players())},
                              {"address", client
                                  ? client->host + ":" + std::to_string(client->port)
                                  : "unavailable"}});
            }
            static_cast<void>(event.set_motd(motd_messages_[index]));
            static_cast<void>(event.set_secondary_motd(
                motd_messages_[(index + 1U) % motd_messages_.size()]));
            static_cast<void>(event.online_players());
            static_cast<void>(event.maximum_players());
        }));
        listener_ids_.push_back(events().subscribe<PlayerCommandEvent>([this](const PlayerCommandEvent& event) {
            if (record_event("player.command")) {
                logger().log(BP_LOG_INFO, "Observed native player.command event",
                             "EXAMPLE.CPP.EVENT_OBSERVED",
                             {{"player", event.player().name}});
            }
            const auto command = event.command();
            if (command == "bpblocked" || command == "/bpblocked") {
                static_cast<void>(event.cancel());
            } else if (command == "bpday" || command == "/bpday") {
                static_cast<void>(event.cancel());
                static_cast<void>(commands().dispatch_server_command("time set day"));
            }
        }, EventPriority::early));
        listener_ids_.push_back(events().subscribe<ServerCommandEvent>([this](const ServerCommandEvent& event) {
            if (record_event("server.command")) {
                logger().log(BP_LOG_INFO, "Observed native server.command event",
                             "EXAMPLE.CPP.EVENT_OBSERVED");
            }
            const auto command = event.command();
            if (command == "bpblockedserver") {
                static_cast<void>(event.cancel());
            } else if (command == "bpnight") {
                static_cast<void>(event.set_command("time set night"));
            }
        }, EventPriority::early));
    }

    void schedule_tasks() {
        task_ids_.push_back(scheduler().run_timeout([this] {
            logger().log(BP_LOG_INFO, "One-shot task ran", "EXAMPLE.CPP.DELAYED_TASK");
        }, 20));
        task_ids_.push_back(scheduler().schedule([this] {
            logger().log(BP_LOG_DEBUG, "Repeating task ran", "EXAMPLE.CPP.REPEATING_TASK");
        }, 2'000, 2'000, 3));
        task_ids_.push_back(scheduler().run_job([this] {
            ++job_step_;
            logger().log(BP_LOG_DEBUG, "C++ job step ran", "EXAMPLE.CPP.JOB_STEP",
                         {{"step", std::to_string(job_step_)}});
            return job_step_ < 3;
        }));
        task_ids_.push_back(scheduler().run_interval([this] {
            const auto current = motd_index_.load(std::memory_order_relaxed);
            motd_index_.store((current + 1U) % motd_messages_.size(),
                              std::memory_order_relaxed);
        }, 100));
        const auto cancelled = scheduler().run_timeout([this] {
            logger().log(BP_LOG_ERROR, "Cancelled task executed", "EXAMPLE.CPP.CANCEL_FAILED");
        }, 1200);
        static_cast<void>(scheduler().clear_run(cancelled));
    }

    [[nodiscard]] static bool run_player_action(Player& player,
                                                const std::string& operation,
                                                const std::string& value) {
        if (operation == "message") return player.send_message(value);
        if (operation == "error") return player.send_error_message(value);
        if (operation == "actionbar") return player.send_action_bar(value);
        if (operation == "title") {
            const auto separator = value.find(',');
            return separator == std::string::npos
                ? player.send_title(value)
                : player.send_title(value.substr(0, separator), value.substr(separator + 1));
        }
        if (operation == "title-clear") return player.clear_title();
        if (operation == "title-reset") return player.reset_title();
        if (operation == "command") return player.perform_command(value);
        if (operation == "transfer") {
            const auto separator = value.find(',');
            if (separator == std::string::npos) return player.transfer(value);
            const auto raw_port = std::stoul(value.substr(separator + 1));
            if (raw_port == 0 || raw_port > 65535) {
                throw std::invalid_argument("transfer port must be between 1 and 65535");
            }
            return player.transfer(value.substr(0, separator),
                                   static_cast<std::uint16_t>(raw_port));
        }
        if (operation == "operator") {
            if (value != "true" && value != "false") {
                throw std::invalid_argument("operator value must be true or false");
            }
            return player.set_operator(value == "true");
        }
        if (operation == "gamemode") {
            if (value == "survival") return player.set_game_mode(GameMode::survival);
            if (value == "creative") return player.set_game_mode(GameMode::creative);
            if (value == "adventure") return player.set_game_mode(GameMode::adventure);
            if (value == "spectator") return player.set_game_mode(GameMode::spectator);
            throw std::invalid_argument("game mode must be survival, creative, adventure, or spectator");
        }
        if (operation == "xp") return player.add_experience(std::stoi(value));
        if (operation == "levels") return player.add_levels(std::stoi(value));
        if (operation == "spawn") return player.set_spawn_point();
        if (operation == "spawn-clear") return player.clear_spawn_point();
        if (operation == "inventory-clear") {
            if (value.empty()) return player.clear_inventory();
            const auto separator = value.find(',');
            if (separator == std::string::npos) return player.clear_inventory(value);
            return player.clear_inventory(value.substr(0, separator), -1,
                                          std::stoi(value.substr(separator + 1)));
        }
        if (operation == "tag-add") return player.add_tag(value);
        if (operation == "tag-remove") return player.remove_tag(value);
        if (operation == "effect") {
            const auto first = value.find(',');
            const auto second = first == std::string::npos ? std::string::npos : value.find(',', first + 1);
            if (first == std::string::npos) {
                throw std::invalid_argument("effect value must be id,duration_ticks[,amplifier]");
            }
            const auto id = value.substr(0, first);
            const auto raw_ticks = std::stoul(value.substr(
                first + 1, second == std::string::npos ? std::string::npos : second - first - 1));
            const auto raw_amplifier = second == std::string::npos
                ? 0UL : std::stoul(value.substr(second + 1));
            if (raw_ticks > 20'000'000UL || raw_amplifier > 255UL) {
                throw std::invalid_argument("effect duration or amplifier is outside the supported range");
            }
            return player.add_effect(id, static_cast<std::uint32_t>(raw_ticks),
                                     static_cast<std::uint8_t>(raw_amplifier));
        }
        if (operation == "effect-clear") {
            return value.empty() ? player.remove_effect() : player.remove_effect(value);
        }
        if (operation == "damage") {
            const auto separator = value.find(',');
            const auto amount = std::stoi(value.substr(0, separator));
            return separator == std::string::npos
                ? player.apply_damage(amount)
                : player.apply_damage(amount, std::string_view{value}.substr(separator + 1));
        }
        if (operation == "kill") return player.kill();
        if (operation == "sound") return player.play_sound(value);
        if (operation == "sound-stop") {
            return value.empty() ? player.stop_sound() : player.stop_sound(value);
        }
        if (operation == "input") {
            const auto separator = value.find(',');
            if (separator == std::string::npos) {
                throw std::invalid_argument("input value must be permission,true|false");
            }
            const auto permission = value.substr(0, separator);
            const auto enabled = value.substr(separator + 1);
            InputPermission parsed;
            if (permission == "camera") parsed = InputPermission::camera;
            else if (permission == "movement") parsed = InputPermission::movement;
            else if (permission == "jump") parsed = InputPermission::jump;
            else if (permission == "lateral_movement") parsed = InputPermission::lateral_movement;
            else if (permission == "sneak") parsed = InputPermission::sneak;
            else if (permission == "dismount") parsed = InputPermission::dismount;
            else if (permission == "mount") parsed = InputPermission::mount;
            else if (permission == "move_backward") parsed = InputPermission::move_backward;
            else if (permission == "move_forward") parsed = InputPermission::move_forward;
            else if (permission == "move_left") parsed = InputPermission::move_left;
            else if (permission == "move_right") parsed = InputPermission::move_right;
            else throw std::invalid_argument("unsupported input permission");
            if (enabled != "true" && enabled != "false") {
                throw std::invalid_argument("input state must be true or false");
            }
            return player.set_input_permission(parsed, enabled == "true");
        }
        if (operation == "camera-shake") {
            const auto first = value.find(',');
            const auto second = first == std::string::npos
                ? std::string::npos : value.find(',', first + 1);
            if (first == std::string::npos || second == std::string::npos) {
                throw std::invalid_argument(
                    "camera-shake value must be intensity,seconds,positional|rotational");
            }
            const auto kind = value.substr(second + 1);
            const auto type = kind == "positional" ? CameraShakeType::positional
                : kind == "rotational" ? CameraShakeType::rotational
                : throw std::invalid_argument("camera shake type is invalid");
            return player.add_camera_shake(std::stod(value.substr(0, first)),
                                           std::stod(value.substr(first + 1, second - first - 1)),
                                           type);
        }
        if (operation == "camera-stop") return player.stop_camera_shake();
        if (operation == "camera") {
            return player.set_camera(value.empty()
                ? static_cast<std::string_view>(CameraPresetTypes::FirstPerson)
                : std::string_view{value});
        }
        if (operation == "camera-clear") return player.clear_camera();
        if (operation == "rotate") {
            const auto separator = value.find(',');
            if (separator == std::string::npos) throw std::invalid_argument("rotation must be pitch,yaw");
            return player.set_rotation(Vector2{std::stod(value.substr(0, separator)),
                                                std::stod(value.substr(separator + 1))});
        }
        if (operation == "look-at") {
            const auto first = value.find(',');
            const auto second = first == std::string::npos ? std::string::npos : value.find(',', first + 1);
            if (first == std::string::npos || second == std::string::npos) {
                throw std::invalid_argument("look-at must be x,y,z");
            }
            return player.look_at(Vector3{std::stod(value.substr(0, first)),
                                           std::stod(value.substr(first + 1, second - first - 1)),
                                           std::stod(value.substr(second + 1))});
        }
        if (operation == "event") return player.trigger_event(value);
        if (operation == "animation") return player.play_animation(value);
        if (operation == "give") {
            const auto separator = value.find(',');
            const auto item_id = value.substr(0, separator);
            const auto count = separator == std::string::npos ? 1UL : std::stoul(value.substr(separator + 1));
            if (count == 0UL || count > 255UL) {
                throw std::invalid_argument("item count must be between 1 and 255");
            }
            return player.give(ItemStack{item_id, static_cast<std::uint16_t>(count), 0, {}});
        }
        throw std::invalid_argument(
            "unknown player operation; use message, error, actionbar, title, title-clear, "
            "title-reset, command, transfer, operator, gamemode, xp, levels, spawn, spawn-clear, "
            "inventory-clear, tag-add, tag-remove, effect, effect-clear, damage, kill, "
            "sound, sound-stop, input, camera-shake, camera-stop, camera, camera-clear, "
            "rotate, look-at, event, animation, or give");
    }

    [[nodiscard]] bool record_event(const std::string_view name) {
        std::scoped_lock lock{event_counts_mutex_};
        auto& count = event_counts_[std::string{name}];
        ++count;
        return count == 1U;
    }

    [[nodiscard]] std::string event_count_summary() const {
        std::scoped_lock lock{event_counts_mutex_};
        if (event_counts_.empty()) return "none";
        std::ostringstream text;
        bool first = true;
        for (const auto& [name, count] : event_counts_) {
            if (!first) text << ", ";
            first = false;
            text << name << '=' << count;
        }
        return text.str();
    }

    std::filesystem::path data_path_;
    std::vector<std::uint64_t> listener_ids_;
    std::vector<std::uint64_t> task_ids_;
    std::unordered_set<std::string> hidden_vanilla_commands_;
    mutable std::mutex event_counts_mutex_;
    std::map<std::string, std::uint64_t, std::less<>> event_counts_;
    std::uint64_t tick_count_{};
    std::uint32_t job_step_{};
    std::atomic_size_t motd_index_{};
};

}  // namespace

BEDROCKPLUS_PLUGIN(
    FullCppPlugin,
    "bedrockplus.example.full-cpp",
    "BedrockPlus Full C++ API Example",
    "1.12.0")
