[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$python = Join-Path $repoRoot '.tools\venvs\development\Scripts\python.exe'
$builder = Join-Path $repoRoot 'tools\bppack.py'
$outputDirectory = Join-Path $repoRoot 'out\examples'
$output = Join-Path $outputDirectory 'bedrockplus-full-api-example-1.7.0.bppack'

if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw 'Bootstrap the project-local development tools first.'
}
New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
& $python -I -B $builder build $PSScriptRoot $output --force
if ($LASTEXITCODE -ne 0) {
    throw "Package build failed with exit code $LASTEXITCODE."
}
Write-Host "Built: $output"
