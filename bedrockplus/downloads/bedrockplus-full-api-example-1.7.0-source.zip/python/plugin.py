"""Complete, typed BedrockPlus API v1 example for BDS 1.26.51.1."""

from __future__ import annotations

import json
from collections.abc import Iterator
from ipaddress import ip_address
from pathlib import Path

from bedrockplus import (
    Block,
    BlockBreakEvent,
    BlockPlaceEvent,
    CommandArgument,
    CommandInvocation,
    CommandResult,
    EventPriority,
    GameMode,
    ItemStack,
    PlayerChatEvent,
    PlayerCommandEvent,
    PlayerJoinEvent,
    PlayerJumpEvent,
    PlayerKickEvent,
    PlayerLoginEvent,
    PlayerMoveEvent,
    PlayerQuitEvent,
    Player,
    PluginHost,
    Server,
    ServerCommandEvent,
    ServerListPingEvent,
    ServerTickEvent,
    System,
    Vector2,
    Vector3,
)


class FullFeaturedPlugin:
    """Reference implementation for the complete working Python host API."""

    id = "bedrockplus.example.full-featured"
    name = "BedrockPlus Full API Example"
    version = "1.7.0"

    motd_messages = (
        "BedrockPlus API example",
        "Typed Python plugins are running",
        "Cancellable events are enabled",
        "Native slash commands are enabled",
        "Scheduled tasks are active",
    )

    def __init__(self) -> None:
        self.host: PluginHost
        self.server: Server
        self.system: System
        self.data_path = Path()
        self.state_path = Path()
        self.state: dict[str, int] = {"starts": 0, "joins": 0}
        self.subscription_ids: list[int] = []
        self.task_ids: list[int] = []
        self.tick_count = 0
        self.motd_index = 0

    def on_load(self, host: PluginHost) -> None:
        """Save the typed host and prepare this plugin's private data path."""
        self.host = host
        self.server = Server(host)
        self.system = System(host)
        self.data_path = self.server.data_directory
        self.state_path = self.data_path / "state.json"
        host.log("info", "EXAMPLE.LOAD", "Full API example loaded")

    def on_enable(self) -> None:
        """Load persistent data before BDS runtime services are registered."""
        self.data_path.mkdir(parents=True, exist_ok=True)
        if self.state_path.is_file():
            try:
                loaded = json.loads(self.state_path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.state["starts"] = int(loaded.get("starts", 0))
                    self.state["joins"] = int(loaded.get("joins", 0))
            except (OSError, ValueError, TypeError):
                self.host.log(
                    "warning",
                    "EXAMPLE.STATE_INVALID",
                    "Invalid state.json was ignored",
                    {"path": str(self.state_path)},
                )
        self.state["starts"] += 1
        self._save_state()
        self.host.log(
            "info",
            "EXAMPLE.ENABLE",
            "Full API example enabled",
            {"starts": str(self.state["starts"])},
        )

    def on_server_ready(self) -> None:
        """Register commands, live event listeners, and scheduled callbacks."""
        if not self.host.commands_available():
            raise RuntimeError("BedrockPlus command service is unavailable")
        if not self.host.events_available():
            raise RuntimeError("BedrockPlus event service is unavailable")
        if not self.host.scheduler_available():
            raise RuntimeError("BedrockPlus scheduler service is unavailable")

        # A native slash command with an alias and optional trailing text.
        self.host.register_command(
            "bpexample",
            self.on_example_command,
            description="Exercise the BedrockPlus Python API",
            aliases=["bpx"],
            overloads=[
                [],
                [
                    CommandArgument(
                        "action", "enum",
                        choices=(
                            "say", "tell", "as", "kick", "player",
                            "hide", "restore", "stats",
                        ),
                    ),
                    CommandArgument("value", "text", optional=True),
                ],
            ],
        )

        # The previous command demonstrates enum autocomplete; this one covers
        # every scalar and trailing-text argument type.
        self.host.register_command(
            "bptypes",
            self.on_types_command,
            description="Test int, number, string, and text arguments",
            overloads=[[
                CommandArgument("count", "int"),
                CommandArgument("ratio", "number"),
                CommandArgument("word", "string"),
                CommandArgument("message", "text"),
            ]],
        )

        # All callbacks receive concrete event classes. HIGH runs before normal
        # listeners. Use event.cancel() and typed mutable properties.
        self.subscription_ids.extend([
            self.host.subscribe_event("server.tick", self.on_tick),
            self.host.subscribe_event("player.login", self.on_player_login),
            self.host.subscribe_event("player.join", self.on_player_join),
            self.host.subscribe_event("player.quit", self.on_player_quit),
            self.host.subscribe_event("player.kick", self.on_player_kick),
            self.host.subscribe_event("player.chat", self.on_player_chat),
            self.host.subscribe_event("player.move", self.on_player_move),
            self.host.subscribe_event("player.jump", self.on_player_jump),
            self.host.subscribe_event("block.break", self.on_block_break),
            self.host.subscribe_event("block.place", self.on_block_place),
            self.host.subscribe_event("server.list_ping", self.on_server_list_ping),
            self.host.subscribe_event(
                "player.command", self.on_player_command, EventPriority.HIGH
            ),
            self.host.subscribe_event(
                "server.command", self.on_server_command, EventPriority.HIGH
            ),
        ])

        # System uses Bedrock ticks (20 ticks = one second), returns task IDs,
        # and exposes both Pythonic and Script-API-style method names.
        self.task_ids.append(self.system.runTimeout(self.on_delayed_task, 20))
        self.task_ids.append(self.system.run(self.on_next_tick_task))
        self.task_ids.append(self.system.runJob(self.example_job()))
        # Rotate the text used by future server-list ping responses every five
        # seconds. The list-ping event itself remains the only place that edits
        # an individual response.
        self.task_ids.append(self.system.runInterval(self.rotate_motd, 100))

        # The low-level host remains useful for a finite repeating task.
        self.task_ids.append(
            self.host.schedule(
                self.on_repeating_task,
                delay_ms=2000,
                interval_ms=2000,
                runs=3,
            )
        )

        # Schedule then cancel a task to show explicit task cancellation.
        cancelled_id = self.system.runTimeout(self.on_cancelled_task, 1200)
        self.system.clearRun(cancelled_id)

        self.host.log(
            "info",
            "EXAMPLE.READY",
            "Try /bpexample, /bptypes, /bpday, and /bpblocked",
            {"server": self.server.name, "api": str(self.server.api_version)},
        )

    def on_example_command(self, invocation: CommandInvocation) -> CommandResult:
        """Handle /bpexample and demonstrate server dispatch/policy APIs."""
        args = invocation.args
        if not args:
            return CommandResult.success(
                    "API example is active. Actions: say, tell, as, kick, player, "
                    "hide, restore, stats. "
                    "Also try /bpday and /bpblocked."
            )

        action = str(args[0]).casefold()
        value = str(args[1]).strip() if len(args) > 1 else ""

        if action == "say":
            if not value:
                return CommandResult.failure("Usage: /bpexample say <text>")
            accepted = self.server.broadcast(f"&d[BedrockPlus example]&r {value}")
            return CommandResult(accepted, "Server command queued" if accepted else "Queue rejected")

        # Player actions use "player name|value" so names may contain spaces.
        if action in {"tell", "as", "kick"}:
            player_name, action_value = self._split_player_action(value)
            if not player_name:
                return CommandResult.failure(
                    f"Usage: /bpexample {action} <player>|<value>"
                )
            player = self.server.player(player_name)
            if action == "tell":
                accepted = bool(action_value) and player.send_message(action_value)
            elif action == "as":
                accepted = bool(action_value) and player.run_command(action_value)
            else:
                accepted = player.kick(action_value or "Kicked by the API example")
            return CommandResult(
                accepted, f"{action} queued for {player.display_name}"
            )

        if action == "player":
            # Syntax: /bpexample player <name>|<operation>|<value>
            # This keeps player names with spaces intact while one reference
            # command demonstrates the complete typed Player action surface.
            player_name, separator, remainder = value.partition("|")
            operation, operation_separator, operation_value = remainder.partition("|")
            if not separator or not operation.strip():
                return CommandResult.failure(
                    "Usage: /bpexample player <name>|<operation>|<value>"
                )
            player = self.server.player(player_name.strip())
            try:
                accepted = self._run_player_api_action(
                    player,
                    operation.strip().casefold(),
                    operation_value.strip() if operation_separator else "",
                )
            except (TypeError, ValueError) as error:
                return CommandResult.failure(str(error), "EXAMPLE_PLAYER_ARGUMENT")
            return CommandResult(
                accepted,
                f"{operation.strip()} queued for {player.display_name}",
            )

        if action in {"hide", "restore"}:
            command_name = value.lstrip("/").split(" ", 1)[0]
            if not command_name:
                return CommandResult.failure(
                    f"Usage: /bpexample {action} <vanilla-command>"
                )
            changed = (
                self.host.hide_vanilla_command(command_name)
                if action == "hide"
                else self.host.restore_vanilla_command(command_name)
            )
            return CommandResult(changed, f"{action}: {command_name}")

        if action == "stats":
            return CommandResult.success(
                    f"starts={self.state['starts']}; joins={self.state['joins']}; "
                    f"source={invocation.source_name}; server={self.server.name}; "
                    f"api={self.server.api_version}"
            )

        return CommandResult.failure(
            f"Unknown action: {action}", "EXAMPLE_UNKNOWN_ACTION"
        )

    def on_types_command(self, invocation: CommandInvocation) -> CommandResult:
        """Receive BDS-parsed int, float, one-token string, and remaining text."""
        count, ratio, word, message = invocation.args
        return CommandResult.success(
                f"count={int(count)}; ratio={float(ratio):g}; "
                f"word={word}; message={message}"
        )

    def on_tick(self, event: ServerTickEvent) -> None:
        """Observe the server-thread tick feed without flooding the log."""
        self.tick_count += 1
        if self.tick_count == 1:
            self.host.log(
                "debug",
                "EXAMPLE.FIRST_TICK",
                "First observed server tick",
                {"sequence": str(event.sequence)},
            )

    def on_player_join(self, event: PlayerJoinEvent) -> None:
        """Read native player fields and persist a join counter."""
        player = event.player
        self.state["joins"] += 1
        self._save_state()
        # Initial spawn is still inside BDS's native lifecycle hook. Defer
        # command-backed actions until the next tick instead of re-entering
        # BDS command processing from that hook.
        def send_welcome() -> None:
            player.send_message("&aWelcome! &fThis message uses the Player object.")

        self.task_ids.append(self.host.schedule(send_welcome, delay_ms=50))
        if player.address is None:
            address = "unavailable (BDS did not provide an endpoint)"
        else:
            try:
                parsed_address = ip_address(player.address.host)
                scope = (
                    "local network"
                    if parsed_address.is_private
                    or parsed_address.is_loopback
                    or parsed_address.is_link_local
                    else "public network"
                )
            except ValueError:
                scope = "network endpoint"
            address = f"{player.address.host}:{player.address.port} ({scope})"
        connection_summary = "\n".join(
            (
                f"Session: {player.session_id}",
                f"XUID: {player.xuid or 'unavailable'}",
                f"Connection data: {'available' if player.connection is not None else 'unavailable'}",
                f"Address: {address}",
                f"Device ID: {player.device_id or 'unavailable'}",
                f"Device model: {player.device_model or 'unavailable'}",
                f"Device OS: {player.device_os or 'unavailable'}",
                f"Input: {player.input_mode or 'unavailable'}",
                f"Game version: {player.game_version or 'unavailable'}",
                f"Locale: {player.locale or 'unavailable'}",
                f"Ping: {player.ping_ms if player.ping_ms is not None else 'unavailable'} ms",
            )
        )
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_JOIN",
            f"{player.display_name} joined\n{connection_summary}",
            {
                "session": player.session_id,
                "connection_available": str(player.connection is not None),
                "ping_ms": str(player.ping_ms) if player.ping_ms is not None else "",
                "device_model": player.device_model,
                "device_os": player.device_os,
                "input_mode": player.input_mode,
                "game_version": player.game_version,
                "locale": player.locale,
                "address": address,
                "device_id": player.device_id,
            },
        )

    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        """Observe a native player disconnect event."""
        player = event.player
        self.host.log(
            "info",
            "EXAMPLE.PLAYER_QUIT",
            f"{player.display_name} left",
            {"session": player.session_id},
        )

    def on_player_login(self, event: PlayerLoginEvent) -> None:
        """Inspect authenticated connection data before the player spawns."""
        player = event.player
        self.host.log(
            "debug",
            "EXAMPLE.PLAYER_LOGIN",
            f"Login accepted for {player.display_name}",
            {"device_model": player.device_model},
        )
        # A real access plugin can set event.kick_message and call event.cancel().

    def on_player_kick(self, event: PlayerKickEvent) -> None:
        """Observe, cancel, or rewrite a native disconnect reason."""
        self.host.log(
            "debug",
            "EXAMPLE.PLAYER_KICK",
            f"{event.player.display_name}: {event.reason}",
        )
        # The reason is mutable: event.reason = "A clearer reason"

    def on_player_chat(self, event: PlayerChatEvent) -> None:
        """Cancel a sample marker or rewrite a chat message before BDS handles it."""
        message = event.message
        if message.casefold() == "!cancel-example":
            event.cancel()
        elif message.startswith("!green "):
            event.message = "§a" + message[7:]

    def on_player_move(self, event: PlayerMoveEvent) -> None:
        """Read typed locations; cancelling restores the accepted position."""
        _to_position = event.to_location.position

    def on_player_jump(self, event: PlayerJumpEvent) -> None:
        """Observe or cancel the rising-edge jump input."""
        _player_name = event.player.display_name
        # event.cancel() prevents this jump input.

    def on_block_break(self, event: BlockBreakEvent) -> None:
        """Handle the pre-action block-break request."""
        block: Block = event.block
        _position = block.position
        # block.type_id and block.level are None when the request hook did not
        # supply an authoritative permutation or dimension. The SDK does not
        # substitute minecraft:air or the overworld.
        # event.cancel() prevents BDS from handling the request.

    def on_block_place(self, event: BlockPlaceEvent) -> None:
        """Handle the pre-action item-use-on-block request."""
        _face = event.block_face
        # event.cancel() prevents BDS from handling the request.

    def on_server_list_ping(self, event: ServerListPingEvent) -> None:
        """Customize MOTD and advertised counts for this list response."""
        event.motd = self.motd_messages[self.motd_index]
        event.secondary_motd = self.motd_messages[
            (self.motd_index + 1) % len(self.motd_messages)
        ]
        # Read the real counts without replacing them with demonstration data.
        _real_online_players = event.online_players
        _real_maximum_players = event.maximum_players
        # event.cancel() suppresses this one response.

    def on_player_command(self, event: PlayerCommandEvent) -> None:
        """Cancel /bpblocked and run /bpday through the server command queue."""
        command = event.command.lstrip("/").casefold()
        if command == "bpblocked":
            event.cancel()
        elif command == "bpday":
            # Rewriting to `time` would retain the player's vanilla permission
            # level. Cancel the player request and dispatch as server instead.
            event.cancel()
            self.server.dispatch_command("time set day")

    def on_server_command(self, event: ServerCommandEvent) -> None:
        """Apply the same control model to commands entered in the console."""
        command = event.command.lstrip("/").casefold()
        if command == "bpblockedserver":
            event.cancel()
        elif command == "bpnight":
            event.command = "time set night"

    def on_delayed_task(self) -> None:
        self.host.log("info", "EXAMPLE.DELAYED_TASK", "One-shot task ran")

    def on_next_tick_task(self) -> None:
        self.host.log("debug", "EXAMPLE.NEXT_TICK_TASK", "system.run task ran")

    def example_job(self) -> Iterator[None]:
        """Yield three times; System advances this generator once per tick."""
        for step in range(3):
            self.host.log("debug", "EXAMPLE.JOB_STEP", f"Job step {step + 1}")
            yield

    def on_repeating_task(self) -> None:
        self.host.log("debug", "EXAMPLE.REPEATING_TASK", "Repeating task ran")

    def rotate_motd(self) -> None:
        """Select the message used for the next server-list ping response."""
        self.motd_index = (self.motd_index + 1) % len(self.motd_messages)

    def on_cancelled_task(self) -> None:
        # This must never execute because it is cancelled in on_server_ready.
        self.host.log("error", "EXAMPLE.CANCEL_FAILED", "Cancelled task executed")

    def on_server_stopping(self) -> None:
        """Explicitly release owned resources before host teardown."""
        for task_id in self.task_ids:
            self.system.clearRun(task_id)
        self.task_ids.clear()

        for subscription_id in self.subscription_ids:
            self.host.unsubscribe_event(subscription_id)
        self.subscription_ids.clear()

        self.host.unregister_command("bpexample")
        self.host.unregister_command("bptypes")
        self.host.log("info", "EXAMPLE.STOPPING", "Example resources released")

    def on_disable(self) -> None:
        self._save_state()
        self.host.log("info", "EXAMPLE.DISABLE", "Full API example disabled")

    def on_unload(self) -> None:
        """No host calls are made after this final lifecycle callback."""

    def _save_state(self) -> None:
        # Keep the reference compatible with Windows security scanners and
        # backup tools that can briefly hold newly-created temporary files.
        self.state_path.write_text(
            json.dumps(self.state, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

    @staticmethod
    def _split_player_action(value: str) -> tuple[str, str]:
        player_name, separator, action_value = value.partition("|")
        return player_name.strip(), action_value.strip() if separator else ""

    @staticmethod
    def _run_player_api_action(
        player: Player,
        operation: str,
        value: str,
    ) -> bool:
        """Exercise typed, validated Player operations from one test command.

        Examples:
          /bpexample player Steve|gamemode|creative
          /bpexample player Steve|effect|minecraft:speed,200,1
          /bpexample player Steve|rotate|0,180

        These methods return command-queue acceptance. They intentionally do
        not claim that BDS completed a command after it entered the queue.
        """
        if operation == "message":
            return player.send_message(value)
        if operation == "gamemode":
            return player.set_game_mode(GameMode(value.casefold()))
        if operation == "xp":
            return player.add_experience(int(value))
        if operation == "levels":
            return player.add_levels(int(value))
        if operation == "spawn":
            return player.set_spawn_point(player.location)
        if operation == "tag-add":
            return player.add_tag(value)
        if operation == "tag-remove":
            return player.remove_tag(value)
        if operation == "effect":
            parts = [part.strip() for part in value.split(",")]
            if len(parts) not in {2, 3}:
                raise ValueError("effect value must be id,duration_ticks[,amplifier]")
            return player.add_effect(
                parts[0],
                int(parts[1]),
                int(parts[2]) if len(parts) == 3 else 0,
            )
        if operation == "effect-clear":
            return player.remove_effect(value or None)
        if operation == "damage":
            amount, separator, cause = value.partition(",")
            return player.apply_damage(int(amount), cause.strip() if separator else None)
        if operation == "kill":
            return player.kill()
        if operation == "sound":
            return player.play_sound(value)
        if operation == "sound-stop":
            return player.stop_sound(value or None)
        if operation == "rotate":
            pitch, yaw = (float(part.strip()) for part in value.split(",", 1))
            return player.set_rotation(Vector2(pitch, yaw))
        if operation == "look-at":
            x, y, z = (float(part.strip()) for part in value.split(",", 2))
            return player.look_at(Vector3(x, y, z))
        if operation == "event":
            return player.trigger_event(value)
        if operation == "animation":
            return player.play_animation(value)
        if operation == "give":
            item_id, separator, count = value.partition(",")
            return player.give(
                ItemStack(item_id.strip(), int(count) if separator else 1)
            )
        raise ValueError(
            "operation must be message, gamemode, xp, levels, spawn, tag-add, "
            "tag-remove, effect, effect-clear, damage, kill, sound, "
            "sound-stop, rotate, look-at, event, animation, or give"
        )
