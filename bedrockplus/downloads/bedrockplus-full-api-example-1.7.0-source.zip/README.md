# BedrockPlus full Python API example

This is the canonical, typed API v1 reference plugin. Version `1.7.0`
demonstrates every
feature that is connected to BDS in the current `1.26.51.1` development build:

- all six lifecycle callbacks;
- structured logs and private persistent data;
- one-shot/repeating scheduling and explicit cancellation;
- a five-message MOTD rotation driven by the scheduler and list-ping event;
- subscription/unsubscription for tick, player lifecycle, chat, movement,
  jump, block request, RakNet list-ping, and global command events;
- command cancellation and in-place rewrite before vanilla execution;
- native `/bpexample` and `/bptypes` registration, aliases, overloads, and the
  `enum`, `int`, `number`, `string`, and `text` argument types, including
  literal action autocomplete;
- vanilla/BedrockPlus server-command dispatch;
- owner-scoped vanilla command hide/restore policies; and
- explicit command unregistration during orderly shutdown.
- typed `Server`, `Player`, `World`, `Level`, `Block`, `Entity`, `Location`,
  `Vector2`, `Vector3`, `GameMode`, `ItemStack`, and `ConnectionInfo` objects;
- validated Player actions for messages, commands, teleport, game mode, XP,
  spawn points, rotation, look-at, tags, effects, damage, sounds, entity events,
  animations, and items. Connection fields remain optional until a native
  producer supplies them. This diagnostic example logs connection fields on join
  so the native bridge can be verified; production plugins should redact sensitive
  IP/device identifiers unless they are operationally required. Unknown block
  type, world, dimension, and connection fields remain `None`; the example does
  not manufacture fallback gameplay values.

The source imports the PEP 561 typed `bedrockplus` package. For IDE autocomplete
in a plugin development environment, run this once from the repository root:

```powershell
python -m pip install -e .\sdk\python
```

## Build and install

```powershell
.\examples\plugins\python-full-featured\Prepare-Package.ps1
Copy-Item .\out\examples\bedrockplus-full-api-example-1.7.0.bppack `
  D:\Minecraft\BedrockPlusEngine\BedrockPlusServer\plugins\
```

Then enter the server folder and run `bedrockplus`.

## In-game tests

```text
/bpexample
/bpx stats
/bpexample say Hello from a plugin
/bpexample tell Player Name|Private message
/bpexample as Player Name|time set day
/bpexample kick Player Name|Example reason
/bpexample player Player Name|gamemode|creative
/bpexample player Player Name|effect|minecraft:speed,200,1
/bpexample player Player Name|rotate|0,180
/bpexample hide me
/bpexample restore me
/bptypes 7 1.5 word remaining text here
/bpday
/bpblocked
```

`/bpday` is cancelled as a player request and queues `time set day` through the
server command dispatcher, so it does not inherit the player's vanilla `time`
permission requirement. `/bpblocked` is cancelled before BDS handles it. In the
server console, `bpnight` is rewritten to `time set night`
and `bpblockedserver` is cancelled.

Chat, movement, jump, login, kick, and request-level block events now have exact
BDS `1.26.51.1` producers. List-ping rewriting is available when BDS uses RakNet.
Block events describe cancellable client pre-action requests; they do not yet
expose the final authoritative block permutation or inventory transaction.
