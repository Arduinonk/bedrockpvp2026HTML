# BedrockPlus full C++ API example

This is the canonical C++20 ABI v1 reference plugin. It demonstrates all six
lifecycle callbacks, structured logging, the private data directory, typed
commands and overloads, vanilla command policies, server-command dispatch,
scheduling and cancellation, and every event feed currently connected to BDS.
It also demonstrates the copied `LevelSnapshot`, `EntitySnapshot`, `PlayerSnapshot`,
`Location`, `Vector3`, `ItemStack`, and `ConnectionInfo` value types.

## Build and package

Run from the repository root in Visual Studio 2022 Developer PowerShell:

```powershell
.\examples\plugins\cpp-full-featured\Prepare-Package.ps1
```

The finished archive is written to
`out/examples/bedrockplus-full-cpp-example-1.0.0.bppack`. Put only that archive
in the server's `plugins/` directory.

## Tests in game and console

```text
/bpcppexample
/bpcpp say Hello from C++
/bpcpp hide me
/bpcpp restore me
/bpcpp stats
/bpcpptypes 7 1.5 word remaining text
/bpcppday
/bpcppblocked
```

Enter `bpnight` or `bpblockedserver` in the server console to test mutable and
cancellable server command events. The reserved chat, block, movement, login,
kick, jump, and server-list ping event names do not yet have native producers.
