#include <bedrockplus/sdk/plugin.hpp>

#include <cstdint>
#include <fstream>
#include <optional>
#include <string>
#include <string_view>
#include <variant>
#include <vector>

namespace {

using bedrockplus::sdk::CommandArgument;
using bedrockplus::sdk::CommandArgumentType;
using bedrockplus::sdk::CommandDefinition;
using bedrockplus::sdk::CommandInvocation;
using bedrockplus::sdk::CommandOverload;
using bedrockplus::sdk::CommandResponse;
using bedrockplus::sdk::ConnectionInfo;
using bedrockplus::sdk::EntitySnapshot;
using bedrockplus::sdk::Event;
using bedrockplus::sdk::EventPriority;
using bedrockplus::sdk::ItemStack;
using bedrockplus::sdk::LevelSnapshot;
using bedrockplus::sdk::Location;
using bedrockplus::sdk::PlayerSnapshot;
using bedrockplus::sdk::Plugin;
using bedrockplus::sdk::SocketAddress;
using bedrockplus::sdk::Vector3;

[[nodiscard]] std::string value_as_text(const CommandInvocation& invocation, const std::size_t index) {
    if (index >= invocation.values.size()) {
        return {};
    }
    if (const auto* text = std::get_if<std::string>(&invocation.values[index])) {
        return *text;
    }
    if (const auto* integer = std::get_if<std::int64_t>(&invocation.values[index])) {
        return std::to_string(*integer);
    }
    return std::to_string(std::get<double>(invocation.values[index]));
}

class FullCppPlugin final : public Plugin {
public:
    using Plugin::Plugin;

    bp_status on_load() override {
        // These copied value objects are safe to keep after callbacks. Native
        // gameplay producers will use the same types as the API grows.
        level_ = LevelSnapshot{"BedrockPlus", "minecraft:overworld"};
        location_ = Location{level_.name, level_.dimension_id, Vector3{0.0, 64.0, 0.0}, 0.0F, 0.0F};
        entity_ = EntitySnapshot{1, "minecraft:player", location_};
        item_ = ItemStack{"minecraft:diamond", 1, 0, "API example"};
        connection_ = ConnectionInfo{SocketAddress{"127.0.0.1", 19132}, 0, "", "", "", "", "", "", std::nullopt};
        player_ = PlayerSnapshot{"Example", "not-connected", "", "", location_, connection_};
        logger().log(BP_LOG_INFO, "Full C++ API example loaded", "EXAMPLE.CPP.LOAD");
        return BP_STATUS_OK;
    }

    bp_status on_enable() override {
        data_path_ = data_directory();
        std::filesystem::create_directories(data_path_);
        std::ofstream{data_path_ / "enabled.txt", std::ios::trunc} << "enabled\n";
        logger().log(BP_LOG_INFO, "Full C++ API example enabled", "EXAMPLE.CPP.ENABLE",
                     {{"level", level_.name}, {"item", item_.type_id}});
        return BP_STATUS_OK;
    }

    void on_server_ready() override {
        register_commands();
        subscribe_events();
        schedule_tasks();
        logger().log(BP_LOG_INFO,
                     "Try /bpcppexample, /bpcpptypes, /bpcppday, and /bpcppblocked",
                     "EXAMPLE.CPP.READY");
    }

    void on_server_stopping() override {
        for (const auto task : task_ids_) {
            static_cast<void>(scheduler().cancel(task));
        }
        task_ids_.clear();
        for (const auto listener : listener_ids_) {
            static_cast<void>(events().unsubscribe(listener));
        }
        listener_ids_.clear();
        static_cast<void>(commands().unregister_command("bpcppexample"));
        static_cast<void>(commands().unregister_command("bpcpptypes"));
        static_cast<void>(commands().restore_vanilla_command("me"));
        logger().log(BP_LOG_INFO, "C++ example resources released", "EXAMPLE.CPP.STOPPING");
    }

    void on_disable() override {
        logger().log(BP_LOG_INFO, "Full C++ API example disabled", "EXAMPLE.CPP.DISABLE");
    }

    void on_unload() override {
        // The host must not be called after this callback returns.
    }

private:
    void register_commands() {
        CommandDefinition example;
        example.name = "bpcppexample";
        example.description = "Exercise the BedrockPlus C++ API";
        example.permission = "any";
        example.aliases = {"bpcpp"};
        example.overloads = {
            CommandOverload{},
            CommandOverload{{
                CommandArgument{"action", CommandArgumentType::enumeration, false,
                                {"say", "hide", "restore", "stats"}},
                CommandArgument{"value", CommandArgumentType::text, true, {}},
            }},
        };
        commands().register_command(example, [this](const CommandInvocation& invocation) {
            if (invocation.values.empty()) {
                return CommandResponse{true, "Actions: say, hide, restore, stats", {}};
            }
            const auto action = value_as_text(invocation, 0);
            const auto value = value_as_text(invocation, 1);
            if (action == "say") {
                const auto accepted = !value.empty() && commands().dispatch_server_command("say " + value);
                return CommandResponse{accepted, accepted ? "Server command queued" : "Queue rejected", {}};
            }
            if (action == "hide" || action == "restore") {
                const auto changed = !value.empty() && (action == "hide"
                    ? commands().hide_vanilla_command(value)
                    : commands().restore_vanilla_command(value));
                return CommandResponse{changed, action + ": " + value, {}};
            }
            if (action == "stats") {
                return CommandResponse{true,
                    "ticks=" + std::to_string(tick_count_) + "; source=" +
                        std::string{invocation.source_name} + "; entity=" + entity_.type_id,
                    {}};
            }
            return CommandResponse{false, "Unknown action: " + action, "EXAMPLE_UNKNOWN_ACTION"};
        });

        CommandDefinition types;
        types.name = "bpcpptypes";
        types.description = "Test all native argument types";
        types.permission = "any";
        types.overloads = {CommandOverload{{
            CommandArgument{"count", CommandArgumentType::integer, false, {}},
            CommandArgument{"ratio", CommandArgumentType::real, false, {}},
            CommandArgument{"word", CommandArgumentType::string, false, {}},
            CommandArgument{"message", CommandArgumentType::text, false, {}},
        }}};
        commands().register_command(types, [](const CommandInvocation& invocation) {
            return CommandResponse{true,
                "count=" + value_as_text(invocation, 0) + "; ratio=" + value_as_text(invocation, 1) +
                    "; word=" + value_as_text(invocation, 2) + "; message=" + value_as_text(invocation, 3),
                {}};
        });
    }

    void subscribe_events() {
        listener_ids_.push_back(events().subscribe("server.tick", [this](const Event& event) {
            ++tick_count_;
            if (tick_count_ == 1) {
                logger().log(BP_LOG_DEBUG, "First observed server tick", "EXAMPLE.CPP.FIRST_TICK",
                             {{"sequence", std::to_string(event.sequence)}});
            }
        }));
        listener_ids_.push_back(events().subscribe("player.join", [this](const Event& event) {
            const auto name = event.field("player.name").value_or("A player");
            logger().log(BP_LOG_INFO, std::string{name} + " joined", "EXAMPLE.CPP.PLAYER_JOIN",
                         {{"session", event.field("player.session").value_or("")}});
            static_cast<void>(commands().dispatch_server_command("tellraw @a {\"rawtext\":[{\"text\":\"§aWelcome from C++!\"}]}"));
        }));
        listener_ids_.push_back(events().subscribe("player.quit", [this](const Event& event) {
            logger().log(BP_LOG_INFO,
                         std::string{event.field("player.name").value_or("A player")} + " left",
                         "EXAMPLE.CPP.PLAYER_QUIT");
        }));
        listener_ids_.push_back(events().subscribe("player.command", [this](const Event& event) {
            const auto command = event.field("command").value_or("");
            if (command == "bpblocked" || command == "/bpblocked") {
                static_cast<void>(event.cancel());
            } else if (command == "bpday" || command == "/bpday") {
                static_cast<void>(event.cancel());
                static_cast<void>(commands().dispatch_server_command("time set day"));
            }
        }, EventPriority::early));
        listener_ids_.push_back(events().subscribe("server.command", [](const Event& event) {
            const auto command = event.field("command").value_or("");
            if (command == "bpblockedserver") {
                static_cast<void>(event.cancel());
            } else if (command == "bpnight") {
                static_cast<void>(event.set_field("command", "time set night"));
            }
        }, EventPriority::early));
    }

    void schedule_tasks() {
        task_ids_.push_back(scheduler().schedule([this] {
            logger().log(BP_LOG_INFO, "One-shot task ran", "EXAMPLE.CPP.DELAYED_TASK");
        }, 1'000));
        task_ids_.push_back(scheduler().schedule([this] {
            logger().log(BP_LOG_DEBUG, "Repeating task ran", "EXAMPLE.CPP.REPEATING_TASK");
        }, 2'000, 2'000, 3));
        const auto cancelled = scheduler().schedule([this] {
            logger().log(BP_LOG_ERROR, "Cancelled task executed", "EXAMPLE.CPP.CANCEL_FAILED");
        }, 60'000);
        static_cast<void>(scheduler().cancel(cancelled));
    }

    std::filesystem::path data_path_;
    LevelSnapshot level_;
    Location location_;
    EntitySnapshot entity_;
    ItemStack item_;
    ConnectionInfo connection_;
    PlayerSnapshot player_;
    std::vector<std::uint64_t> listener_ids_;
    std::vector<std::uint64_t> task_ids_;
    std::uint64_t tick_count_{};
};

}  // namespace

BEDROCKPLUS_PLUGIN(
    FullCppPlugin,
    "bedrockplus.example.full-cpp",
    "BedrockPlus Full C++ API Example",
    "1.0.0")
