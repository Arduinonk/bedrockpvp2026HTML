#include <bedrockplus/sdk/plugin.hpp>

#include <array>
#include <atomic>
#include <cstdint>
#include <fstream>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_set>
#include <variant>
#include <vector>

namespace {

using bedrockplus::sdk::CommandArgument;
using bedrockplus::sdk::CommandArgumentType;
using bedrockplus::sdk::CommandDefinition;
using bedrockplus::sdk::CommandInvocation;
using bedrockplus::sdk::CommandOverload;
using bedrockplus::sdk::CommandResponse;
using bedrockplus::sdk::Event;
using bedrockplus::sdk::EventPriority;
using bedrockplus::sdk::GameMode;
using bedrockplus::sdk::ItemStack;
using bedrockplus::sdk::PlayerSnapshot;
using bedrockplus::sdk::Player;
using bedrockplus::sdk::Plugin;
using bedrockplus::sdk::Vector3;
using bedrockplus::sdk::Vector2;

[[nodiscard]] std::string value_as_text(const CommandInvocation& invocation, const std::size_t index) {
    if (index >= invocation.values.size()) {
        return {};
    }
    if (const auto* text = std::get_if<std::string>(&invocation.values[index])) {
        return *text;
    }
    if (const auto* integer = std::get_if<std::int64_t>(&invocation.values[index])) {
        return std::to_string(*integer);
    }
    return std::to_string(std::get<double>(invocation.values[index]));
}

class FullCppPlugin final : public Plugin {
public:
    using Plugin::Plugin;

    bp_status on_load() override {
        logger().log(BP_LOG_INFO, "Full C++ API example loaded", "EXAMPLE.CPP.LOAD");
        return BP_STATUS_OK;
    }

    bp_status on_enable() override {
        data_path_ = data_directory();
        std::filesystem::create_directories(data_path_);
        std::ofstream{data_path_ / "enabled.txt", std::ios::trunc} << "enabled\n";
        logger().log(BP_LOG_INFO, "Full C++ API example enabled", "EXAMPLE.CPP.ENABLE");
        return BP_STATUS_OK;
    }

    void on_server_ready() override {
        register_commands();
        subscribe_events();
        schedule_tasks();
        logger().log(BP_LOG_INFO,
                     "Try /bpcppexample, /bpcpptypes, /bpcppday, and /bpcppblocked",
                     "EXAMPLE.CPP.READY");
    }

    void on_server_stopping() override {
        for (const auto task : task_ids_) {
            static_cast<void>(scheduler().clear_run(task));
        }
        task_ids_.clear();
        for (const auto listener : listener_ids_) {
            static_cast<void>(events().unsubscribe(listener));
        }
        listener_ids_.clear();
        static_cast<void>(commands().unregister_command("bpcppexample"));
        static_cast<void>(commands().unregister_command("bpcpptypes"));
        for (const auto& command : hidden_vanilla_commands_) {
            static_cast<void>(commands().restore_vanilla_command(command));
        }
        hidden_vanilla_commands_.clear();
        logger().log(BP_LOG_INFO, "C++ example resources released", "EXAMPLE.CPP.STOPPING");
    }

    void on_disable() override {
        logger().log(BP_LOG_INFO, "Full C++ API example disabled", "EXAMPLE.CPP.DISABLE");
    }

    void on_unload() override {
        // The host must not be called after this callback returns.
    }

private:
    static constexpr std::array<std::string_view, 5> motd_messages_{
        "BedrockPlus C++ API example",
        "Typed native plugins are running",
        "Cancellable events are enabled",
        "Native slash commands are enabled",
        "Scheduled tasks are active",
    };

    void register_commands() {
        CommandDefinition example;
        example.name = "bpcppexample";
        example.description = "Exercise the BedrockPlus C++ API";
        example.permission = "";
        example.aliases = {"bpcpp"};
        example.overloads = {
            CommandOverload{},
            CommandOverload{{
                CommandArgument{"action", CommandArgumentType::enumeration, false,
                                {"say", "player", "hide", "restore", "stats"}},
                CommandArgument{"value", CommandArgumentType::text, true, {}},
            }},
        };
        commands().register_command(example, [this](const CommandInvocation& invocation) {
            if (invocation.values.empty()) {
                return CommandResponse{true, "Actions: say, hide, restore, stats", {}};
            }
            const auto action = value_as_text(invocation, 0);
            const auto value = value_as_text(invocation, 1);
            if (action == "say") {
                const auto accepted = !value.empty() && commands().dispatch_server_command("say " + value);
                return CommandResponse{accepted, accepted ? "Server command queued" : "Queue rejected", {}};
            }
            if (action == "player") {
                // Syntax: /bpcppexample player <name>|<operation>|<value>
                const auto first = value.find('|');
                const auto second = first == std::string::npos
                    ? std::string::npos : value.find('|', first + 1);
                if (first == std::string::npos || first == 0) {
                    return CommandResponse{false,
                        "Usage: /bpcppexample player <name>|<operation>|<value>",
                        "EXAMPLE_PLAYER_ARGUMENT"};
                }
                const auto name = value.substr(0, first);
                const auto operation = value.substr(
                    first + 1,
                    second == std::string::npos ? std::string::npos : second - first - 1);
                const auto argument = second == std::string::npos ? std::string{} : value.substr(second + 1);
                try {
                    Player player{commands(), PlayerSnapshot{name, "", "", "", std::nullopt, std::nullopt}};
                    const auto accepted = run_player_action(player, operation, argument);
                    return CommandResponse{accepted, operation + " queued for " + player.display_name(), {}};
                } catch (const std::exception& error) {
                    return CommandResponse{false, error.what(), "EXAMPLE_PLAYER_ARGUMENT"};
                }
            }
            if (action == "hide" || action == "restore") {
                const auto changed = !value.empty() && (action == "hide"
                    ? commands().hide_vanilla_command(value)
                    : commands().restore_vanilla_command(value));
                if (changed && action == "hide") {
                    hidden_vanilla_commands_.insert(value);
                } else if (changed) {
                    hidden_vanilla_commands_.erase(value);
                }
                return CommandResponse{changed, action + ": " + value, {}};
            }
            if (action == "stats") {
                return CommandResponse{true,
                    "ticks=" + std::to_string(tick_count_) + "; source=" +
                        std::string{invocation.source_name},
                    {}};
            }
            return CommandResponse{false, "Unknown action: " + action, "EXAMPLE_UNKNOWN_ACTION"};
        });

        CommandDefinition types;
        types.name = "bpcpptypes";
        types.description = "Test all native argument types";
        types.permission = "";
        types.overloads = {CommandOverload{{
            CommandArgument{"count", CommandArgumentType::integer, false, {}},
            CommandArgument{"ratio", CommandArgumentType::real, false, {}},
            CommandArgument{"word", CommandArgumentType::string, false, {}},
            CommandArgument{"message", CommandArgumentType::text, false, {}},
        }}};
        commands().register_command(types, [](const CommandInvocation& invocation) {
            return CommandResponse{true,
                "count=" + value_as_text(invocation, 0) + "; ratio=" + value_as_text(invocation, 1) +
                    "; word=" + value_as_text(invocation, 2) + "; message=" + value_as_text(invocation, 3),
                {}};
        });
    }

    void subscribe_events() {
        listener_ids_.push_back(events().subscribe("server.tick", [this](const Event& event) {
            ++tick_count_;
            if (tick_count_ == 1) {
                logger().log(BP_LOG_DEBUG, "First observed server tick", "EXAMPLE.CPP.FIRST_TICK",
                             {{"sequence", std::to_string(event.sequence)}});
            }
        }));
        listener_ids_.push_back(events().subscribe("player.join", [this](const Event& event) {
            auto snapshot = event.player_snapshot();
            if (!snapshot) throw std::runtime_error("player.join did not contain a player snapshot");
            logger().log(BP_LOG_INFO, snapshot->name + " joined", "EXAMPLE.CPP.PLAYER_JOIN",
                         {{"session", snapshot->session_id}, {"xuid", snapshot->xuid}});
            Player player{commands(), std::move(*snapshot)};
            static_cast<void>(player.send_message("&aWelcome from the typed C++ Player API!"));
        }));
        listener_ids_.push_back(events().subscribe("player.quit", [this](const Event& event) {
            const auto snapshot = event.player_snapshot();
            if (!snapshot) {
                logger().log(BP_LOG_WARN, "player.quit had no identity",
                             "EXAMPLE.CPP.PLAYER_QUIT_MALFORMED");
                return;
            }
            logger().log(BP_LOG_INFO, snapshot->name + " left", "EXAMPLE.CPP.PLAYER_QUIT");
        }));
        listener_ids_.push_back(events().subscribe("player.login", [this](const Event& event) {
            const auto snapshot = event.player_snapshot();
            if (!snapshot) {
                logger().log(BP_LOG_WARN, "player.login had no identity",
                             "EXAMPLE.CPP.PLAYER_LOGIN_MALFORMED");
                return;
            }
            logger().log(BP_LOG_DEBUG,
                         std::string{"Login accepted for "} + snapshot->name,
                         "EXAMPLE.CPP.PLAYER_LOGIN",
                         {{"device_model", snapshot->connection
                             ? snapshot->connection->device_model : std::string{}}});
            // A real access plugin can call event.cancel() here.
        }));
        listener_ids_.push_back(events().subscribe("player.kick", [this](const Event& event) {
            const auto snapshot = event.player_snapshot();
            if (!snapshot) {
                logger().log(BP_LOG_WARN, "player.kick had no identity",
                             "EXAMPLE.CPP.PLAYER_KICK_MALFORMED");
                return;
            }
            logger().log(BP_LOG_DEBUG,
                         snapshot->name + ": " +
                             std::string{event.field("reason").value_or("")},
                         "EXAMPLE.CPP.PLAYER_KICK");
            // The reason is mutable: event.set_field("reason", "A clearer reason").
        }));
        listener_ids_.push_back(events().subscribe("player.chat", [](const Event& event) {
            const auto message = event.field("message").value_or("");
            if (message == "!cancel-example") {
                static_cast<void>(event.cancel());
            } else if (message.starts_with("!green ")) {
                static_cast<void>(event.set_field("message", std::string{"\xC2\xA7" "a"} +
                                                          std::string{message.substr(7)}));
            }
        }, EventPriority::early));
        listener_ids_.push_back(events().subscribe("player.move", [](const Event& event) {
            // from.* and to.* are strings containing finite decimal numbers.
            // The five to.* fields may be rewritten; event.cancel() restores
            // the previous accepted packet position.
            static_cast<void>(event.field("to.x"));
        }));
        listener_ids_.push_back(events().subscribe("player.jump", [](const Event& event) {
            // Calling event.cancel() here prevents this jump input.
            static_cast<void>(event.field("player.name"));
        }));
        listener_ids_.push_back(events().subscribe("block.break", [](const Event& event) {
            // Pre-action request. Coordinates and face are exposed as strings.
            static_cast<void>(event.field("block.x"));
        }));
        listener_ids_.push_back(events().subscribe("block.place", [](const Event& event) {
            // Calling event.cancel() prevents BDS from handling this request.
            static_cast<void>(event.field("block.face"));
        }));
        listener_ids_.push_back(events().subscribe("server.list_ping", [this](const Event& event) {
            // MOTD can be changed for this one RakNet response without editing
            // server.properties. Real player counts remain unchanged.
            const auto index = motd_index_.load(std::memory_order_relaxed);
            static_cast<void>(event.set_field("motd", motd_messages_[index]));
            static_cast<void>(event.set_field(
                "motd.secondary", motd_messages_[(index + 1U) % motd_messages_.size()]));
            static_cast<void>(event.field("players.online"));
            static_cast<void>(event.field("players.maximum"));
        }));
        listener_ids_.push_back(events().subscribe("player.command", [this](const Event& event) {
            const auto command = event.field("command").value_or("");
            if (command == "bpblocked" || command == "/bpblocked") {
                static_cast<void>(event.cancel());
            } else if (command == "bpday" || command == "/bpday") {
                static_cast<void>(event.cancel());
                static_cast<void>(commands().dispatch_server_command("time set day"));
            }
        }, EventPriority::early));
        listener_ids_.push_back(events().subscribe("server.command", [](const Event& event) {
            const auto command = event.field("command").value_or("");
            if (command == "bpblockedserver") {
                static_cast<void>(event.cancel());
            } else if (command == "bpnight") {
                static_cast<void>(event.set_field("command", "time set night"));
            }
        }, EventPriority::early));
    }

    void schedule_tasks() {
        task_ids_.push_back(scheduler().run_timeout([this] {
            logger().log(BP_LOG_INFO, "One-shot task ran", "EXAMPLE.CPP.DELAYED_TASK");
        }, 20));
        task_ids_.push_back(scheduler().schedule([this] {
            logger().log(BP_LOG_DEBUG, "Repeating task ran", "EXAMPLE.CPP.REPEATING_TASK");
        }, 2'000, 2'000, 3));
        task_ids_.push_back(scheduler().run_job([this] {
            ++job_step_;
            logger().log(BP_LOG_DEBUG, "C++ job step ran", "EXAMPLE.CPP.JOB_STEP",
                         {{"step", std::to_string(job_step_)}});
            return job_step_ < 3;
        }));
        task_ids_.push_back(scheduler().run_interval([this] {
            const auto current = motd_index_.load(std::memory_order_relaxed);
            motd_index_.store((current + 1U) % motd_messages_.size(),
                              std::memory_order_relaxed);
        }, 100));
        const auto cancelled = scheduler().run_timeout([this] {
            logger().log(BP_LOG_ERROR, "Cancelled task executed", "EXAMPLE.CPP.CANCEL_FAILED");
        }, 1200);
        static_cast<void>(scheduler().clear_run(cancelled));
    }

    [[nodiscard]] static bool run_player_action(Player& player,
                                                const std::string& operation,
                                                const std::string& value) {
        if (operation == "message") return player.send_message(value);
        if (operation == "gamemode") {
            if (value == "survival") return player.set_game_mode(GameMode::survival);
            if (value == "creative") return player.set_game_mode(GameMode::creative);
            if (value == "adventure") return player.set_game_mode(GameMode::adventure);
            if (value == "spectator") return player.set_game_mode(GameMode::spectator);
            throw std::invalid_argument("game mode must be survival, creative, adventure, or spectator");
        }
        if (operation == "xp") return player.add_experience(std::stoi(value));
        if (operation == "levels") return player.add_levels(std::stoi(value));
        if (operation == "spawn") return player.set_spawn_point();
        if (operation == "tag-add") return player.add_tag(value);
        if (operation == "tag-remove") return player.remove_tag(value);
        if (operation == "effect") {
            const auto first = value.find(',');
            const auto second = first == std::string::npos ? std::string::npos : value.find(',', first + 1);
            if (first == std::string::npos) {
                throw std::invalid_argument("effect value must be id,duration_ticks[,amplifier]");
            }
            const auto id = value.substr(0, first);
            const auto raw_ticks = std::stoul(value.substr(
                first + 1, second == std::string::npos ? std::string::npos : second - first - 1));
            const auto raw_amplifier = second == std::string::npos
                ? 0UL : std::stoul(value.substr(second + 1));
            if (raw_ticks > 20'000'000UL || raw_amplifier > 255UL) {
                throw std::invalid_argument("effect duration or amplifier is outside the supported range");
            }
            return player.add_effect(id, static_cast<std::uint32_t>(raw_ticks),
                                     static_cast<std::uint8_t>(raw_amplifier));
        }
        if (operation == "effect-clear") {
            return value.empty() ? player.remove_effect() : player.remove_effect(value);
        }
        if (operation == "damage") {
            const auto separator = value.find(',');
            const auto amount = std::stoi(value.substr(0, separator));
            return separator == std::string::npos
                ? player.apply_damage(amount)
                : player.apply_damage(amount, std::string_view{value}.substr(separator + 1));
        }
        if (operation == "kill") return player.kill();
        if (operation == "sound") return player.play_sound(value);
        if (operation == "sound-stop") {
            return value.empty() ? player.stop_sound() : player.stop_sound(value);
        }
        if (operation == "rotate") {
            const auto separator = value.find(',');
            if (separator == std::string::npos) throw std::invalid_argument("rotation must be pitch,yaw");
            return player.set_rotation(Vector2{std::stod(value.substr(0, separator)),
                                                std::stod(value.substr(separator + 1))});
        }
        if (operation == "look-at") {
            const auto first = value.find(',');
            const auto second = first == std::string::npos ? std::string::npos : value.find(',', first + 1);
            if (first == std::string::npos || second == std::string::npos) {
                throw std::invalid_argument("look-at must be x,y,z");
            }
            return player.look_at(Vector3{std::stod(value.substr(0, first)),
                                           std::stod(value.substr(first + 1, second - first - 1)),
                                           std::stod(value.substr(second + 1))});
        }
        if (operation == "event") return player.trigger_event(value);
        if (operation == "animation") return player.play_animation(value);
        if (operation == "give") {
            const auto separator = value.find(',');
            const auto item_id = value.substr(0, separator);
            const auto count = separator == std::string::npos ? 1UL : std::stoul(value.substr(separator + 1));
            if (count == 0UL || count > 255UL) {
                throw std::invalid_argument("item count must be between 1 and 255");
            }
            return player.give(ItemStack{item_id, static_cast<std::uint16_t>(count), 0, {}});
        }
        throw std::invalid_argument(
            "unknown player operation; use message, gamemode, xp, levels, spawn, tag-add, "
            "tag-remove, effect, effect-clear, damage, kill, sound, sound-stop, "
            "rotate, look-at, event, animation, or give");
    }

    std::filesystem::path data_path_;
    std::vector<std::uint64_t> listener_ids_;
    std::vector<std::uint64_t> task_ids_;
    std::unordered_set<std::string> hidden_vanilla_commands_;
    std::uint64_t tick_count_{};
    std::uint32_t job_step_{};
    std::atomic_size_t motd_index_{};
};

}  // namespace

BEDROCKPLUS_PLUGIN(
    FullCppPlugin,
    "bedrockplus.example.full-cpp",
    "BedrockPlus Full C++ API Example",
    "1.4.0")
