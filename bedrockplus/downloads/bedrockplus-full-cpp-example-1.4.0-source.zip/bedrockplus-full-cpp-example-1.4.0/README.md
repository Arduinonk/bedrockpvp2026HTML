# BedrockPlus full C++ API example

This is the canonical C++20 ABI v1 reference plugin. It demonstrates all six
lifecycle callbacks, structured logging, the private data directory, typed
commands and overloads, vanilla command policies, server-command dispatch,
scheduling and cancellation, a five-message MOTD rotation, and every event feed
currently connected to BDS.
It consumes real copied `PlayerSnapshot`, `Location`, and `ConnectionInfo`
values from event fields and uses `Vector2`, `Vector3`, and `ItemStack` with the
safe typed `Player` class for validated command-backed operations. Other SDK
snapshot types are available to native producers, but the example does not
fabricate world, block, entity, connection, or player data merely to display a
type.

## Build and package

Run from the repository root in Visual Studio 2022 Developer PowerShell:

```powershell
.\examples\plugins\cpp-full-featured\Prepare-Package.ps1
```

The finished archive is written to
`out/examples/bedrockplus-full-cpp-example-1.4.0.bppack`. Put only that archive
in the server's `plugins/` directory.

## Tests in game and console

```text
/bpcppexample
/bpcpp say Hello from C++
/bpcpp player Player Name|gamemode|creative
/bpcpp player Player Name|effect|minecraft:speed,200,1
/bpcpp player Player Name|rotate|0,180
/bpcpp hide me
/bpcpp restore me
/bpcpp stats
/bpcpptypes 7 1.5 word remaining text
/bpcppday
/bpcppblocked
```

Enter `bpnight` or `bpblockedserver` in the server console to test mutable and
cancellable server command events. The example also subscribes to live chat,
movement, jump, login, kick, request-level block, and RakNet list-ping events.
