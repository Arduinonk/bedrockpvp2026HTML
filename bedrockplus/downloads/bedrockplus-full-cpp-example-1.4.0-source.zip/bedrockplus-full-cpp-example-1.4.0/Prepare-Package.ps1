[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$buildDirectory = Join-Path $repoRoot 'out\examples\cpp-full-featured-build'
$python = Join-Path $repoRoot '.tools\venvs\development\Scripts\python.exe'
$builder = Join-Path $repoRoot 'tools\bppack.py'
$payload = Join-Path $PSScriptRoot 'package'
$outputDirectory = Join-Path $repoRoot 'out\examples'
$output = Join-Path $outputDirectory 'bedrockplus-full-cpp-example-1.4.0.bppack'

if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw 'Bootstrap the project-local development tools first.'
}

if (-not (Get-Command cmake -CommandType Application -ErrorAction SilentlyContinue)) {
    . (Join-Path $repoRoot 'toolchain\enter-dev-shell.ps1')
}
$cmake = (Get-Command cmake -CommandType Application -ErrorAction Stop).Source

& $cmake -S $PSScriptRoot -B $buildDirectory -G 'Visual Studio 17 2022' -A x64 `
    "-DBEDROCKPLUS_ROOT=$repoRoot"
if ($LASTEXITCODE -ne 0) { throw 'C++ example configuration failed.' }
& $cmake --build $buildDirectory --config Release
if ($LASTEXITCODE -ne 0) { throw 'C++ example build failed.' }

New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
& $python -I -B $builder build $payload $output --force
if ($LASTEXITCODE -ne 0) { throw 'C++ example package build failed.' }
Write-Host "Built: $output"
